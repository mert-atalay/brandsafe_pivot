# API Spec (MVP, v3)

This is the backend contract the web app calls.
All Gemini calls happen on the server.

## Conventions
- JSON request/response
- Images returned as asset ids (files served via `/assets/{id}`)
- For MVP, store files on disk; later swap to Supabase.

---

## Health
### GET /health
Returns `{ ok: true }`.

---

## Brands
### POST /brands
Create a brand kit.

### GET /brands
List brands.

### GET /brands/{id}
Fetch brand kit.

### PUT /brands/{id}
Update brand kit.

### POST /brands/{id}/assets
Upload brand assets (logo, reference images, winning ads).
Returns asset ids.

---

## Generation

### POST /generate/copy
Input:
```json
{ "brand_id": "...", "creative_brief": { } }
```
Output:
```json
{ "copy_variants": [ ... ], "warnings": [ ... ] }
```

### POST /generate/image/mode-a
Input:
```json
{
  "brand_id": "...",
  "prompt_spec": { },
  "model_preference": "pro|fast",
  "aspect_ratio": "4:5",
  "image_size": "1K",
  "text_mode": "overlay|in_image_headline",
  "hero_object_asset_id": "optional"
}
```
Output:
```json
{ "base_image_asset_id": "...", "model_used": "...", "warnings": [ ... ] }
```

### POST /edit/reference/mode-b
Input:
```json
{
  "brand_id": "...",
  "reference_asset_id": "...",
  "edit_spec": { },
  "placement": "4:5",
  "protected_zones": [ { "x":0, "y":0, "w":0, "h":0 } ]
}
```
Output:
```json
{ "variants": [ ... ] }
```

### POST /generate/pack
Input:
```json
{ "brand_id": "...", "pack_spec": { } }
```
Output:
```json
{ "pack_id": "...", "variants": [ ... ] }
```

---

## Brand Composer (templates + overlays)
### POST /compose
Input: `{ brand_id, base_image_asset_id, template_id, copy_id }`  
Output: `{ composited_asset_id }`

---

## Agent (Creative Director)
### POST /agent/chat
Input:
```json
{
  "brand_id": "...",
  "pack_id": "optional",
  "message": "...",
  "context": { "current_prompt_spec": { } }
}
```
Output:
```json
{
  "assistant_message": "...",
  "actions": [
    { "type": "update_prompt_spec", "patch": { } },
    { "type": "regenerate", "scope": "pack|variant", "id": "..." }
  ]
}
```

---

## Assets
### GET /assets/{id}
Serves image/video file.

### GET /packs/{id}/export
Returns zip download.

---

## Video (Phase 2)
### POST /video/generate
Returns `{ operation_id }`

### GET /video/operation/{operation_id}
Returns status + video asset id when ready.
