# Andromeda‑Parametric Prompt Engine (v3)

This doc defines **how BrandSafe forces meaningful creative diversity** (especially for Meta).

It upgrades our system from *narrative prompts* (“act like a photographer…”) to **parametric prompts** where the backend rotates hard variables (camera / lighting / distance / composition) so each output is visually distinct.

---

## 1) The core problem
Narrative prompting causes modern image models to “normalize” requests. If you ask 5 times for “a professional ad photo,” you often get 5 **near‑duplicate** outputs.

In the Andromeda‑era environment, that’s a business risk: visually similar assets get clustered together during retrieval. Our generator must therefore **force pixel diversity** by rotating parameters that materially change the visual embedding (lens, distance, lighting, scene pattern, composition).

---

## 2) The P.D.A. matrix (Persona, Desire, Awareness)

We adopt the **P.D.A.** framework:

- **P — Persona**: defines the *subject* (who is present / who we’re speaking to).
- **D — Desire**: defines the *emotional vibe* and pushes lighting/mood.
- **A — Awareness**: defines the *message structure* and layout needs.

Why it works:
- It keeps outputs strategically grounded,
- while also mapping directly to **Andromeda diversity levers**.

### Mapping
| PDA | What it controls | Examples |
|---|---|---|
| Persona | subject + props + setting realism | “Busy parent”, “first‑time buyer”, “homeowner” |
| Desire | vibe + lighting + motion | calm/soft, urgent/high contrast, premium/low‑key |
| Awareness | copy structure + composition needs | problem‑aware (pain), solution‑aware (benefit), product‑aware (offer) |

---

## 3) The “Laws of Physics” (system rules)

These are injected into the **image system instruction** (Mode A and Mode B):

1) **OUTPUT PHYSICS**: generate **one single full‑frame image**. No grids. No collages. No split‑screens.  
2) **TEXT PHYSICS**: if text is requested *inside* the image, render it on a **physical surface** (sign, phone screen, paper, wall). No floating overlay text unless explicitly “neon”.  
3) **DIVERSITY ENFORCEMENT**: obey provided camera + lighting + scene constraints. Do not revert to “generic studio” defaults.  
4) **BRAND SAFETY**: maintain product geometry; do not invent or distort logos/wordmarks.

---

## 4) PromptSpec: what the backend must control

The backend assembles a **PromptSpec** per variant.

Minimum fields:
- `persona_label` (abstract)
- `desire_label`
- `awareness_stage`
- `hook_angle`
- `scene_pattern`
- `camera_lens` (e.g., 24mm wide, 85mm portrait, 100mm macro)
- `camera_distance` (wide / mid / close)
- `lighting_style` (golden hour, hard flash, cool neon, low‑key studio)
- `composition_rule` (rule of thirds, centered, dutch tilt, POV)
- `negative_space_rule` (template‑derived instruction)
- `text_container` (only if in‑image text enabled)
- `hero_object_mode` (none | anchor_by_reference)
- `platform_placement` (1:1, 4:5, 9:16, 16:9)

---

## 5) Diversity Dictionary (pack presets)

When the user clicks “Auto‑Generate Pack”, the backend should iterate presets that are *mathematically distinct*.

### Core 5 preset archetypes
1) **Authentic / Social Proof**
   - Pattern: UGC selfie
   - Lens: phone front camera / 24mm
   - Lighting: natural window light (high key)
   - Composition: informal, slight motion

2) **Authority / Trust**
   - Pattern: studio portrait / expert
   - Lens: 85mm portrait
   - Lighting: 3‑point crisp
   - Composition: clean, eye‑level

3) **Visceral / Texture**
   - Pattern: macro texture / product detail
   - Lens: 100mm macro
   - Lighting: hard rim / moody
   - Composition: close detail, tactile

4) **Urgent / FOMO**
   - Pattern: action / dutch tilt
   - Lens: wide (low POV)
   - Lighting: flash / high contrast
   - Composition: kinetic, punchy

5) **Lifestyle / Benefit**
   - Pattern: environmental wide
   - Lens: 35mm lifestyle
   - Lighting: warm golden hour
   - Composition: spacious, aspirational

For an **8–12 pack**, expand by:
- rotating settings (home / outdoors / workplace / store / studio),
- rotating people (none / single / duo / group),
- rotating time of day (morning / afternoon / evening),
- rotating composition (centered vs rule‑of‑thirds vs POV),
while keeping the core 5 presets as anchors.

---

## 6) Enforcement algorithm (practical)

**Pack generator must guarantee:**
- each variant has a unique `(scene_pattern, camera_lens, lighting_style)` triple, and
- each variant differs in at least **2** of: lens, lighting, distance, composition.

**Then validate:**
- copy similarity threshold (semantic or n‑gram)
- visual descriptor overlap (keywords + stored preset ids)

If diversity score < threshold:
- regenerate only the conflicting variants (max 2 retries per variant).

---

## 7) Brand text & logo strategy (BrandSafe)

We support two safe modes:

### Mode A1 — “BrandSafe Overlay” (recommended default)
- Gemini generates the scene (and optionally hero object) **without** brand logos/wordmarks.
- Backend **Brand Composer** overlays the official logo + copy using templates and safe zones.

### Mode A2 — “In‑Image Headline” (optional)
- Gemini renders short headline text **inside the scene** on a physical surface.
- Logo is still composited by Brand Composer.
- Use this mode when speed matters and perfect typography is not required.

Mode B (reference edit) should prefer semantic editing and keep existing brand elements intact.
