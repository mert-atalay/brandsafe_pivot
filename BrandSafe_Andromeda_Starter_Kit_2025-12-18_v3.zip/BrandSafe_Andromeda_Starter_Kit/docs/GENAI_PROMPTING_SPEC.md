# GenAI Prompting Spec (Gemini / Nano Banana Pro) — v3

This document defines **how we prompt** and **how we configure** Gemini calls so outputs are:
- on‑brief
- brand‑safe
- diversified (Andromeda‑era)
- compatible with Gemini 3 Pro Image (Nano Banana Pro)

## Models (Dec 2025)
- **Text / Agent / Copy**: `gemini-3-pro-preview` (or `gemini-3-flash-preview` for cheaper agent/chat)
- **Image Pro** (Nano Banana Pro): `gemini-3-pro-image-preview` (default)
- **Image Fast**: `gemini-2.5-flash-image` (fallback + optional toggle)

## Core philosophy (non‑negotiable)
1) **Never ask Gemini to invent logos/wordmarks.**
2) Use the intermediate layer:
   `SegmentSignals → CreativeBrief → PromptSpec → GenerationResult → (optional) Brand Composer → Export`
3) **Diversity is parametric, not narrative.**
   - Rotation of lens + lighting + distance is enforced (see `docs/ANDROMEDA_PARAMETRIC_ENGINE.md`).

## Gemini config (critical)

### Image generation / edit config
- Aspect ratios MUST use **colon format**:
  - `"1:1"`, `"4:5"`, `"9:16"`, `"16:9"`
- Use `imageSize` for Pro:
  - `"1K"` default
  - `"2K"` optional
- Prefer `responseModalities: ["TEXT","IMAGE"]` during dev/debug.
- Auto fallback:
  - Pro fails? retry once with Fast.

**JS shape (Google GenAI SDK)**
```js
const resp = await ai.models.generateContent({
  model: "gemini-3-pro-image-preview",
  contents: [{ role: "user", parts: contentParts }],
  config: {
    responseModalities: ["TEXT", "IMAGE"],
    imageConfig: {
      aspectRatio: "4:5",
      imageSize: "1K"
    }
  }
});
```

### Multi‑image conditioning (“temporary LoRA”)
When a brand has reference images:
- attach up to **8–10** images for Pro (keep lower for Fast)
- tell the model: “Use these as product/style references.”
- emphasize: “Preserve product geometry and markings.”

## Image system instruction (“laws of physics”)
Always include the following in the *system* portion for image models:
- Generate **one single full‑frame** image (no grids/collage).
- If rendering text *inside* the image, it must be on a **physical surface** (sign/phone/paper/wall).
- Obey camera + lighting constraints; do not normalize them away.
- Do not generate logos/wordmarks unless explicitly provided and requested as an overlay step (we don’t do that in MVP).

(See `docs/ANDROMEDA_PARAMETRIC_ENGINE.md`.)

---

## Mode A — New Creative (Visual Conditioning)

**Goal:** Generate a cohesive ad scene with strong diversity.

### Inputs
- PromptSpec (pattern, hook, lens, lighting, composition, negative space)
- Optional: hero product reference image(s)
- Optional: brand style references (winning ads)

### Rules
- No invented logos/wordmarks.
- If BrandSafe Overlay mode is ON:
  - do not render marketing text inside the image
  - leave negative space per template
- If In‑Image Headline mode is ON:
  - allow a short headline only, placed on a physical surface
  - still do NOT generate the logo (logo is composited)

### Prompt structure (Mode A user prompt)
1) Scene intent (what the ad should feel like)
2) Setting + people + action (pattern)
3) Camera lens + distance + POV (hard)
4) Lighting physics (hard)
5) Composition + negative space instruction (template derived)
6) Optional: hero object anchoring instruction
7) Hard constraints (no grid/collage; no invented logos)

---

## Mode B — Reference Edit (Semantic Editing first)

**Goal:** Edit only what’s allowed (usually background + people), while preserving brand elements.

Gemini 3 Pro Image supports conversational / multi‑turn editing. Prefer:
- Provide the reference image as inlineData
- Use chat history (SDK handles thought signatures)
- Instruction: “Change only the background and people. Keep all existing text and logos unchanged.”

### Protection Overlay Map (pragmatic helper)
Because Gemini does not expose a native pixel‑mask inpainting API in Gemini 3:
- Create a “protection overlay” image that highlights the protected rectangles.
- Provide it as a second conditioning image.
- Prompt: “Treat highlighted areas as locked; do not modify.”

### Brand‑safety fallback
If protected regions change noticeably:
- Run a pixel‑diff check inside protected rectangles.
- If diff > threshold, fallback to overlaying the original protected regions on top of the edited output.

---

## Copy generation (structured JSON)
Always request strict JSON:
- `headlines[]` (short; Meta‑friendly)
- `primary_texts[]` (short/standard/long preset)
- `descriptions[]` (optional, for cross‑platform)
- `ctas[]` (optional)
- `hook_angle`
- `awareness_stage`
- `compliance_notes[]`

---

## Auto‑fallback rules
- Pro fails? Retry once with Fast.
- Fast fails? Return a clear error message and log request ids.

---

## Evaluation prompts (recommended)
Use Gemini as a critic (text‑only) to:
- score hook strength
- detect risky claims
- detect near‑duplicate copy
- verify “physics rules” (no collage; safe zones respected)

See `docs/AD_SCORING_SPEC.md`.
