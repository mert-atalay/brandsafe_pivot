# Test Plan (MVP, v3)

## Unit tests (API)
- Template loader validates zones within bounds
- Brand Composer places logo within template zone
- Brand Composer text rendering respects safe zones
- Copy validator rejects non‑JSON outputs
- Compliance checker flags risky claims
- Diversity scorer penalizes near‑duplicates
- Mode B protected‑region drift detector (pixel‑diff) works

## Integration tests
- POST `/generate/pack` returns expected variant count
- Pro model failure triggers fallback once (then succeeds or errors cleanly)
- Returned image dimensions match requested aspect ratio
- Reference edit works with JPG and PNG inputs (MIME detection)
- Export zip contains images + copy + manifest with correct naming

## Manual checks
- Mode A (BrandSafe Overlay) images contain no invented logos/wordmarks
- Mode A (In‑Image Headline) places headline on a physical surface (no floating overlay)
- Reference edit preserves logo/text; if drift happens, fallback restore keeps them intact
- Pack contains real variety (angle + pattern + lens/lighting badges differ)
- UI results grid scrolls; previews are not hidden below the fold
