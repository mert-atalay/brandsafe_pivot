# UI/UX Spec (v3) — inspired by Pencil, built for SMB speed

## Design goals
- Clean, spacious, card-based
- Feels like: “upload brand → generate diversified ad pack → export”
- Minimal jargon. No prompt engineering required.
- Preview-first: results appear immediately, not hidden behind tabs.
- **Parametric controls** are shown as simple toggles (lens/lighting badges), not raw prompt text.

## Navigation (MVP)
Left nav:
- Home
- Brand Library
- Generate Pack
- Reference Edit
- Video (Coming soon)

Top bar:
- Brand selector
- Export actions (when in a pack)

---

## Screen details

### 1) Home
- “Start” cards:
  - **Generate Pack** (primary)
  - Reference Edit
  - Brand Library
- Recent packs list (last 10)

### 2) Brand Library
Purpose: store context learning assets per brand.
- Upload logo(s)
- Upload 5–10 reference images (product photos + winning ads)
- Brand colors chips (manual)
- Brand voice (adjectives + do/don’t)
- Save

### 3) Generate Pack (main)
**Layout:** left inputs, center results grid, right agent sidebar.

Left inputs (keep short):
- Objective (Lead / Sales / Awareness)
- Placements (1:1, 4:5, 9:16, 16:9)
- Offer / CTA
- Audience signals (chips + freeform)
- Pack size (8–12)
- Diversity threshold slider (0.60–0.85)
- Model preference: Pro / Fast (default Pro; fallback always on)
- Text mode:
  - BrandSafe Overlay (default)
  - In‑Image Headline (optional)
- ImageSize: 1K (default) / 2K (toggle)

Center results:
- Grid of Variant Cards
- Each card shows:
  - thumbnail
  - hook angle + scene pattern
  - **lens + lighting badges** (so users “see” diversity)
  - score (0–100)
  - warnings badges
  - quick actions: Regenerate / Mark Winner / Download

Right sidebar: **Creative Director Agent**
- Chat input
- “Suggested tweaks” quick chips (e.g., “More premium”, “More urgent”, “Try UGC”)
- When user requests change:
  - agent updates generation knobs
  - triggers regenerate pack or selected variants

### 4) Reference Edit
Layout: left controls, right preview.

- Upload reference creative
- Placement selector (auto-detect optional)
- Protection:
  - Toggle: “Keep existing logo/text unchanged”
  - Optional rectangle editor to emphasize protected zones
- Edits:
  - background: (season, setting, time)
  - people: (swap / remove / keep)
  - style: (UGC / studio / premium)
- Generate variations (4–8)

### 5) Video (Phase 2)
Disabled with “Coming soon” panel.
- animate a winning static creative
- generate short 6–8s clips with Veo

---

## Accessibility & usability
- Always allow vertical scrolling in results areas.
- Sticky left panel inputs, scrollable results grid.
- Never hide generated assets below the fold without scroll.
