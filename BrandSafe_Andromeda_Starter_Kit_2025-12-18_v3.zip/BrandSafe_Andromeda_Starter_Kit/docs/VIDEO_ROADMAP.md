# Video Roadmap (Phase 2)

Video is valuable for Meta performance, but it should not block the static MVP.
This roadmap defines how to add Veo cleanly after v1 ships.

## Reality check (Dec 2025)
- Veo 3.1 is available via Gemini API as **long‑running operations**.
- Output videos are typically **~8 seconds** with optional native audio.
- Aspect ratios supported: **"16:9" and "9:16"**.

Official Gemini API model ids:
- `veo-3.1-generate-preview` (higher quality)
- `veo-3.1-fast-generate-preview` (faster/cheaper)

## Phase 2A — “Video Lite” (fast win)
**Goal:** Turn a static generated ad into a simple motion asset.

Options:
1) **Image-to-video** using Veo with a single first frame (the composited ad or base image).
2) If Veo access is limited, fallback to a local “Ken Burns” style animation (pan/zoom) for previews.

Output:
- 8s MP4 in 9:16 and/or 16:9.

## Phase 2B — “Ingredients to Video”
Use up to three reference images:
- product photo
- lifestyle image
- brand texture/scene

Then prompt Veo to create a consistent short ad clip.

## Required backend structure
Add these API primitives:
- POST `/video/generate`
  - body: `{ brand_id, placement, prompt, first_frame_image_id?, reference_image_ids?, model_preference }`
  - returns: `{ operation_id }`

- GET `/video/operation/{operation_id}`
  - returns: `{ status, progress?, video_asset_id? }`

Storage:
- Store mp4 in local disk for MVP; Supabase storage later.

## UX plan (simple)
- New “Video” tab (disabled until Phase 2 is implemented)
- When enabled:
  - choose: “Animate this image” OR “Generate new video concept”
  - choose ratio: 9:16 or 16:9
  - start job → progress indicator → preview player → export

## Prompting guidance (ads)
For ad videos, prompts should be short and structured:
- 1 clear subject
- 1 clear action
- 1 scene
- 1 camera style
- forbid on-frame text (we’ll overlay text in editing or keep text-free videos)

## Key constraint
Do NOT build complex timeline editing. Keep it “generate + export.”
