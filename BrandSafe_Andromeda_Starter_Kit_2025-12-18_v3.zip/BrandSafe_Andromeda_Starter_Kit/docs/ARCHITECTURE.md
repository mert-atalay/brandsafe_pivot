# Architecture (MVP, Meta‑first) — v3

## Stack
- Frontend: React + Vite + TypeScript
- Backend: Python FastAPI (async)
- Storage: Local filesystem (MVP), Supabase Storage optional
- DB: Optional (Supabase Postgres) for brands + packs + feedback + embeddings

## High‑level flow
Web app → FastAPI → (Gemini text + image) → diversification enforcement → (optional) Brand Composer → scoring/compliance → storage → web previews/export

## Why server‑side generation
- Do not expose API keys in the browser
- Central retries + fallback logic
- Centralized logging, rate limiting, caching
- Enables future features (video LRO operations, webhooks, performance ingestion)

---

## Backend modules (suggested)

### `core/`
- `types.py` (Pydantic models for all shared schemas)
- `config.py` (env vars, model ids, limits)

### `brand/`
- `brand_kit.py` (CRUD BrandKit)
- `assets.py` (logo + reference image storage)

### `parametric/`
- `andromeda_engine.py`
  - builds `PromptSpec` from `CreativeBrief`
  - rotates lens/lighting/distance presets (hard diversity)
  - validates pack diversity (score 0–1)

### `generation/`
- `copy.py` (Gemini text → strict JSON)
- `image_mode_a.py` (Visual Conditioning generation, Pro + Fast fallback)
- `image_mode_b.py` (Semantic edit with protection overlay + fallback restore)
- `pack.py` (orchestrates angles + patterns + parametric presets)

### `composer/` (BrandSafe overlays)
- `templates.py` (load template JSON)
- `render.py` (Pillow compositing: logo + text into safe zones)
- `protected_regions.py` (rect defs + pixel diff checks + optional restore overlay)

### `agent/` (MVP differentiator)
- `creative_director.py`
  - chat endpoint
  - tool/function calling to update PromptSpec fields
  - can trigger regenerate actions

### `scoring/`
- `score.py` (heuristic score + optional critic)
- `diversity.py` (pack diversity subscore)

### `compliance/`
- `checks.py` (claims + overflow + similarity warnings)

### `storage/`
- `local.py`
- `supabase.py` (optional)

### `video/` (Phase 2)
- `veo.py` (generateVideos + polling)

---

## Frontend modules (suggested)
- `pages/Home` (start cards + recent packs)
- `pages/BrandKit` (brand library)
- `pages/GeneratePack` (campaign builder + results + agent sidebar)
- `pages/ReferenceEdit`
- `pages/Video` (disabled until Phase 2)

Shared UI:
- `PreviewGrid`
- `VariantCard` (score + warnings + parameter badges)
- `ZoneEditor` (simple rectangles)
- `AgentChatPanel`

---

## Data model highlights
- **BrandKit**
  - logo(s), colors, voice, reference_images[], winning_ads[]
- **CreativeBrief**
  - objective, placements, offer, audience signals, PDA labels
- **PromptSpec**
  - hook angle, pattern
  - lens + distance + lighting
  - composition + negative space rule
  - hero object anchoring (optional)
- **Variant**
  - promptSpec
  - base_image_id
  - composited_image_ids[] (if Brand Composer used)
  - copy_json
  - score + warnings + diversity_subscore
