# Compliance & Brand-Safety Guardrails (v3)

BrandSafe is not “no rules.” It is **rules first**.
This document defines guardrails for:
- prompt generation
- copy generation
- brand compositing
- output checks

## High-level rules (always)
1) Do not generate or encourage disallowed content.
2) Do not use deceptive claims.
3) Don’t impersonate real people or brands.
4) Don’t generate sensitive personal data.

---

## Copy guardrails
### Prohibited / risky claims (warn or block)
- Guaranteed results (“guaranteed”, “100%”, “instant cure”)
- Health/medical claims unless user provides compliant approved wording
- Financial promises (“make $10k/week”)
- Superlatives without proof (“#1”, “best in the world”) unless user provides substantiation

### Style guardrails
- Avoid shaming, fearmongering, or manipulative language
- Avoid political/controversial targeting language unless explicitly requested and allowed

---

## Image guardrails
### Mode A (new creative)
Default text mode = **BrandSafe Overlay**
- No invented logos / brand wordmarks in the generated image.
- Prefer no marketing text inside the generated image (copy is overlaid by Brand Composer).
- No watermarks.

Optional text mode = **In‑Image Headline**
- Allow only the provided headline.
- Headline must be rendered on a physical surface (no floating overlay).
- Still no invented logos/wordmarks.

### Mode B (reference edit)
- Must preserve:
  - existing logo/wordmark
  - existing marketing text
  - product/packaging identity
- Allowed changes:
  - background
  - people (if the user requests)
  - lighting/mood (within reason)

If brand elements drift:
- flag the output
- use brand‑safety fallback restore (protected region overlay)

---

## Platform safety (Meta-first)
MVP checks should warn on:
- text overlay that invades safe zones
- tiny unreadable text
- aggressive urgency language (spammy)
- “collage/grid” outputs (one full-frame image required)

We do NOT attempt to bypass platform review systems.

---

## Enforcement approach
- **Before generation**: prompt guardrails (reject risky inputs)
- **After generation**: output checks
  - copy risk scanner (regex + critic model)
  - similarity check within pack
  - layout collision check (zones)
  - protected-region drift check (Mode B)

---

## Logging
Log only what’s needed to debug:
- request id
- model id
- config
- short hashed representation of prompts (optional)
Never log raw API keys.
