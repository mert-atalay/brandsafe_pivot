# Brand Kit Spec (v3)

The Brand Kit is the center of “context learning.”
We are not fine‑tuning in MVP; we are conditioning on saved brand assets (“temporary LoRA”).

## BrandKit fields
- `brand_id`
- `brand_name`
- `website_url` (optional)

### Visual identity
- `logos[]`: `{ id, name, file_url, preferred_background: 'light'|'dark'|'transparent' }`
- `colors[]`: `{ name, hex }`
- `fonts[]`: `{ name, file_url }` (optional MVP)

### Context learning assets
- `reference_images[]`: product photos + lifestyle imagery (5–10 recommended)
- `winning_ads[]`: optional curated best creatives (can be included in reference_images for MVP)

### Voice
- `voice.adjectives[]` (3–6)
- `voice.do[]`
- `voice.dont[]`

### Compliance notes (optional)
- `approved_claims[]`
- `disallowed_claims[]`
- `required_disclaimers[]`

---

## “In‑Context RAG” (how learning works)
For each generation call:
1) Retrieve top brand assets (logos, colors, voice rules, best ads) from storage.
2) Attach select reference images as multimodal context.
3) Inject short “brand rules” text into the system prompt.

Later (Phase 1.5+): store embeddings for winning ads and retrieve the top‑K most similar assets to the current brief.

---

## Brand‑safe rules
- Do NOT ask Gemini to invent logos/wordmarks.
- Default output mode is **BrandSafe Overlay**:
  - logo + most copy are rendered by the Brand Composer using templates.
- Optional “In‑Image Headline” mode:
  - Gemini may render a short headline on a physical surface.
  - Logo is still composited (not generated).
