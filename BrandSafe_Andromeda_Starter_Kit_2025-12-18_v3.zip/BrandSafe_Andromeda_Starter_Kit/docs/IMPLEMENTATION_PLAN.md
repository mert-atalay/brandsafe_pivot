# Implementation Plan (v3)

This plan is ordered to get a usable Meta‑first MVP fast, without painting us into a corner.

## Phase 0 — Repo + dev sanity (Day 0)
- Monorepo scaffold: `apps/web` (Vite React TS) + `apps/api` (FastAPI)
- One command to run both (dev script)
- Local file storage (`apps/api/storage/`)
- Smoke tests (API health route, basic UI render)

## Phase 1 — Brand Library (context learning backbone)
- BrandKit CRUD:
  - logo(s)
  - colors
  - voice
  - reference images (5–10) + winning ads (optional)
- Store/retrieve brand assets for generation calls

## Phase 2 — Templates + Brand Composer (brand safety)
- Implement Template JSON spec (4 Meta sizes)
- Implement Pillow Brand Composer:
  - logo placement
  - text rendering (headline, CTA)
  - safe-zone collision detection
- Implement export zip naming per `docs/EXPORT_FORMATS_SPEC.md`

## Phase 3 — Andromeda‑Parametric engine (diversity backbone)
- Implement `CreativeBrief` → `PromptSpec`
- Implement preset rotation (pattern + lens + lighting + distance)
- Implement diversity score and “regenerate conflicts” logic

## Phase 4 — Generation (copy + image)
- Copy generation endpoint:
  - strict JSON outputs
  - awareness + hook‑angle aware
- Image Mode A endpoint (Visual Conditioning):
  - Pro default (`gemini-3-pro-image-preview`)
  - Fast fallback (`gemini-2.5-flash-image`)
  - optional hero object anchoring (reference images)
  - enforce aspect ratio + image size + no collage
- Image Mode B endpoint (Semantic Edit):
  - reference image MIME detection
  - “keep brand elements unchanged” prompt
  - optional Protection Overlay Map input

## Phase 5 — Pack generator (MVP main workflow)
- Implement “PackSpec” → list of variants:
  - each variant = hook angle + scene pattern + parametric preset
- Generate base images + copy per variant
- Apply Brand Composer overlays (default mode)
- Surface diversity score in UI

## Phase 6 — Brand‑safety fallback for Mode B
- Protected zones:
  - default from template safe zones
  - optional user rectangles
- After Mode B edit, detect drift via pixel‑diff inside protected zones
- If drift > threshold, restore protected zones via overlay

## Phase 7 — Scoring + compliance (MVP confidence)
- Implement score (0–100) per `docs/AD_SCORING_SPEC.md`
- Implement compliance checks per `docs/COMPLIANCE_GUARDRAILS.md`
- Show reasons + warnings in UI

## Phase 8 — Creative Director Agent (light MVP)
- Add chat panel in UI
- Implement `/agent/chat` endpoint with tool calling:
  - update prompt spec fields
  - trigger regenerate for pack/variant

## Phase 9 — UX polish
- Scrollable results grid
- Fast regenerate + “mark winner”
- Export all assets

## Phase 10 — Phase 2 (video)
- Add `Video` tab and backend scaffolding for Veo (see `docs/VIDEO_ROADMAP.md`)
- Do not block MVP on video.
