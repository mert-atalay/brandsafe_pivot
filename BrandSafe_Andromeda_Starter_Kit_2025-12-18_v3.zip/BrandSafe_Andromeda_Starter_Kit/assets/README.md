# Assets (placeholders + where to put your brand files)

This folder exists to make local development easy.

## What to put here (real projects)
Per brand, you’ll typically have:
- `logo_primary.png` (transparent)
- `logo_white.png` (for dark backgrounds)
- `product_1.jpg` ... `product_10.jpg` (product/reference images)
- `winning_ad_1.png` ... (optional)

## What is included in this starter kit
- Placeholder images you can use to test:
  - compositing
  - safe zones
  - reference editing

Replace them with real brand assets in your project.
