# MASTER PROMPT — Build **BrandSafe Andromeda Studio** from scratch (v3, 2025‑12‑18)

**Use this prompt inside Google Antigravity.**
Recommended agent model: **Claude Opus 4.5**.

Goal: ship a working **Meta‑first MVP** for SMBs that generates **brand‑safe ad packs** (copy + images) using **Gemini (Nano Banana Pro)** with **Andromeda‑era diversification**, plus **scoring** and **compliance**.

This v3 spec incorporates a strategic pivot:
- **Mode A** switches from “template compositing a hero product PNG” → **multimodal anchoring** (Visual Conditioning).
- **Mode B** switches from “hard pixel‑locking everything” → **semantic editing first**, with a brand‑safety fallback if needed.
- We add an **Andromeda‑Parametric engine** that forces pixel‑level diversity via camera/lens/lighting rotation.
- We add a lightweight **Creative Director Agent** (chat) that can adjust generation parameters without exposing prompts to the user.

---

## 0) Instructions to the Agent (non‑negotiable)

You are a senior full‑stack engineer + product builder.

You MUST:
- Read **all docs** in `/docs` before coding.
- Implement the MVP in small, verifiable steps.
- Prefer correctness + debuggability over cleverness.
- Implement the **Gold Layer**: `Signals → Brief → PromptSpec → Result → (optional) Brand Composer → Export`.
- Run Gemini calls **server‑side (FastAPI)** so keys aren’t in the browser.
- Follow the **Andromeda‑Parametric Prompt Engine** rules: rotate camera lens + distance + lighting + pattern.

You MUST NOT:
- Copy Pencil UI 1:1. Use it as vibe inspiration, but build an original interface.
- Ask Gemini to invent logos/wordmarks.

---

## 1) What to build

Build a **monorepo** with:
- `apps/web` → React + Vite + TypeScript (UI)
- `apps/api` → Python FastAPI (async) (Gemini calls, pack generation, scoring, storage)
- `packages/shared` → shared types (optional)

Storage:
- MVP: local disk under `apps/api/storage/`
- Supabase optional toggle later (auth + storage + RAG)

Reference specs:
- Product + scope: `docs/PRODUCT_VISION.md`, `docs/PRD_MVP.md`
- Parametric Andromeda engine: `docs/ANDROMEDA_PARAMETRIC_ENGINE.md`
- Diversification rules: `docs/ANDROMEDA_CREATIVE_RULES.md`, `docs/CREATIVE_PATTERNS_LIBRARY.md`
- Prompting: `docs/GENAI_PROMPTING_SPEC.md`
- Brand kit: `docs/BRAND_KIT_SPEC.md`
- Templates/safe zones: `docs/TEMPLATE_SAFE_ZONES.md` + `/templates/*.json`
- Scoring: `docs/AD_SCORING_SPEC.md`
- Compliance: `docs/COMPLIANCE_GUARDRAILS.md`
- API: `docs/API_SPEC.md`
- Export naming: `docs/EXPORT_FORMATS_SPEC.md`
- Video plan: `docs/VIDEO_ROADMAP.md` (Phase 2)

---

## 2) Core user flows (MVP)

### Flow A — Brand Library (context learning)
Screen: **Brand Library**
- Brand name
- Upload logo(s)
- Upload 5–10 reference images (product photos + winning ads)
- Brand colors (chips)
- Brand voice (adjectives + do/don’t)
- (Optional) “Disallowed claims / required disclaimers”
Persist as `BrandKit`.

### Flow B — Generate Pack (main workflow)
Screen: **Generate Pack**
Inputs (left panel):
- Objective: Lead / Sales / Awareness
- Placements: 1:1, 4:5, 9:16, 16:9
- Offer + CTA
- Audience signals (chips + freeform)
- Pack size (8–12 default)
- Diversity threshold (0.60–0.85 default 0.70)
- Model preference: Pro default, Fast optional (fallback always on)
- Text mode:
  - **BrandSafe Overlay** (default): Gemini generates scene; backend overlays logo + copy
  - **In‑Image Headline** (optional): Gemini renders headline on a physical surface (logo still overlaid)

Output (center/right):
- Variant grid with thumbnails
- Each card shows:
  - Hook angle + pattern + lens + lighting preset
  - Score (0–100) + 3–6 “why” bullets
  - Warning badges
  - Actions: Regenerate / Download / Mark Winner

RIGHT SIDEBAR (MVP differentiator):
- **Creative Director Agent** chat
  - User can say: “Make this more premium”, “More urgency”, “Try UGC”
  - Agent edits the generation parameters (PromptSpec) and triggers regen.
  - Agent reads BrandKit context automatically.

### Flow C — Reference Edit (semantic editing variations)
Screen: **Reference Edit**
- Upload a reference creative (PNG/JPG)
- Placement selector
- Protection intent:
  - “Keep all existing logo/text unchanged” (default)
  - optional: draw rectangles to emphasize “protected zones”
- Edit knobs:
  - background (season/setting/time)
  - people (swap / remove / keep)
  - style (UGC / studio / premium)
Generate 4–8 variations.

---

## 3) The “Gold Layer” (MUST IMPLEMENT)

Implement the intermediate abstraction layer:

1) `SegmentSignals` (raw UI inputs)
2) `CreativeBrief` (sanitized + structured)
3) `PromptSpec` (parametric: hook + pattern + lens + lighting + negative space)
4) `GenerationResult` (raw outputs)
5) `BrandComposerAsset` (optional: overlay logo/text; exports templates)
6) `PackExport` (zip)

This prevents over‑literal outputs and keeps everything consistent.

---

## 4) Gemini models + config (must match official docs)

### Models
- Strategy / Agent / Copy: `gemini-3-pro-preview` (or `gemini-3-flash-preview` for cost)
- Image Pro: `gemini-3-pro-image-preview`
- Image Fast: `gemini-2.5-flash-image`

### Image config rules
- Use `responseModalities: ["TEXT","IMAGE"]` during development; allow prod to use `["IMAGE"]`.
- Aspect ratios MUST use colon format values: `"1:1"`, `"4:5"`, `"9:16"`, `"16:9"`.
- `imageSize`: Pro defaults `"1K"`; allow `"2K"` as a simple toggle.
- Auto‑fallback: if a Pro request fails, retry **once** with Fast.

### Reference image MIME
- For data URLs, extract `mimeType` from the prefix.
- Use `inlineData: { mimeType, data }` where data is base64 without the header.

---

## 5) Mode A generation (Visual Conditioning, not compositing the hero product)

**Mode A goal:** generate a cohesive ad scene that is diverse and on‑brief.

Rules:
- If a **hero product image** is available, pass it as a reference image and instruct:
  - “This is the Hero Object. Preserve its geometry and markings.”
  - “Integrate it naturally (correct lighting/shadows).”
- If no hero product exists (service businesses), generate lifestyle scenes without product.
- Do **not** ask the model to invent brand logos/wordmarks.
- Use **template‑to‑prompt** translation:
  - Convert safe‑zone JSON into natural language “negative space” instructions.

Optional:
- If text mode = In‑Image Headline, ask for headline text only on a physical surface (no floating text).

---

## 6) Mode B generation (Semantic Editing first)

**Mode B goal:** create high‑fidelity variations of an existing creative.

Primary strategy:
- Use `gemini-3-pro-image-preview` in multi‑turn editing mode when possible.
- Prompt: “Change only background/people; keep existing logo and text unchanged.”

Because Gemini 3 does not provide native pixel‑mask inpainting, implement a pragmatic brand‑safety fallback:
- Build a **Protection Overlay Map** (a copy of the reference with highlighted protected rectangles) as an additional conditioning image.
- If the output still alters protected regions (simple pixel‑diff check inside rectangles), fallback to:
  - overlay the original protected regions onto the edited output.

This keeps the default experience “Pencil‑style semantic editing”, but still preserves brand safety when needed.

---

## 7) Diversification enforcement (must feel real)

A pack must show meaningful variety across:
- Hook angles
- Scene patterns
- Camera lens + distance + POV
- Lighting physics
- Copy opening + promise framing

Implement:
- `diversityScore(pack) -> 0..1`
- Per pack, force unique `(pattern, lens, lighting)` triples (see `docs/ANDROMEDA_PARAMETRIC_ENGINE.md`).
- Regenerate conflicting variants until diversity ≥ threshold or attempts == 2.

---

## 8) Scoring + compliance (MVP confidence)

Implement per variant:
- Score (0–100) using `docs/AD_SCORING_SPEC.md`
- Warnings using `docs/COMPLIANCE_GUARDRAILS.md`
- Add an “Andromeda diversity” subscore that checks hard‑parameter uniqueness.

Show these in the UI.

---

## 9) Deliverables & Acceptance Tests

### Deliverables
- Working UI: Home, Brand Library, Generate Pack, Reference Edit
- Creative Director Agent panel (simple)
- FastAPI endpoints per `docs/API_SPEC.md`
- Template system works for 4 Meta sizes
- Export zip follows `docs/EXPORT_FORMATS_SPEC.md`

### Acceptance tests (manual)
- Generate Pack creates 8+ variants with real angle+pattern+lens+lighting diversity
- Mode A can run:
  - with hero product reference image (anchoring) OR without product
- BrandSafe Overlay exports pixel‑perfect logo/text
- Mode B:
  - semantic edit works, and if protected elements change, fallback preserves them
- Score + warnings render in UI
- Pro default + Fast fallback works

---

## 10) Implementation order (recommended)
1) Repo scaffold + dev scripts
2) Brand Kit CRUD + storage
3) Parametric engine (PromptSpec + pack preset rotation)
4) Gemini: copy generator + Mode A image generator
5) Brand Composer templates (overlay logo/text)
6) Generate Pack workflow + diversity validation
7) Reference Edit workflow + protection fallback
8) Scoring + compliance
9) Agent panel (function calling to update PromptSpec)
10) UX polish + export

---

## 11) Phase 2 (plan ahead, don’t block MVP)
- Video generation via Veo / Gemini video (see `docs/VIDEO_ROADMAP.md`)
- Performance feedback loop (mark winners; later ingest Meta/Google results)
- Supabase Auth + RAG retrieval over winning ads
