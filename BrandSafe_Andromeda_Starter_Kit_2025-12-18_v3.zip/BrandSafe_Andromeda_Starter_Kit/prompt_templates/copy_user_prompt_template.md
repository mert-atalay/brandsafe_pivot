INPUTS:
- brand_voice_adjectives: {{brand_voice_adjectives}}
- offer: {{offer}}
- cta: {{cta}}
- audience_signals: {{audience_signals}}
- objective: {{objective}}
- hook_angle: {{hook_angle}}
- scene_pattern: {{scene_pattern}}
- placement: {{placement}}
- primary_text_length: {{primary_text_length}}  # short|standard|long
- constraints: {{constraints}}

TASK:
Write direct-response ad copy that matches the hook angle + scene pattern.

Generate:
- 5 headlines (<= 40 chars)
- 5 primary texts (length preset above)
- 4 descriptions (<= 90 chars)

Hard rules:
- Do NOT use any fake testimonials.
- Do NOT invent certifications, pricing, or guarantees.
- Use brand voice adjectives.

Return STRICT JSON:
{
  "objective": "...",
  "hook_angle": "...",
  "scene_pattern": "...",
  "headlines": ["..."],
  "primary_texts": ["..."],
  "descriptions": ["..."],
  "compliance_notes": ["..."]
}
