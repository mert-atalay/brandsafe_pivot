# Mode A — Image Prompt Template (v3)
Use this as the **user prompt** for image generation.

> System rules (“laws of physics”) should be added in the system instruction.
> See `docs/ANDROMEDA_PARAMETRIC_ENGINE.md`.

---

## Creative Brief (Parametric)
- platform_placement: {{platform_placement}} (aspect ratio {{aspect_ratio}})
- objective: {{objective}}
- persona_label: {{persona_label}}
- desire_label: {{desire_label}}
- awareness_stage: {{awareness_stage}}
- hook_angle: {{hook_angle}}
- scene_pattern: {{scene_pattern}}

## Hard Visual Parameters (do not normalize)
- camera_lens: {{camera_lens}}
- camera_distance: {{camera_distance}}
- camera_pov: {{camera_pov}}
- lighting_style: {{lighting_style}}
- composition_rule: {{composition_rule}}

## Template / Layout Guidance
- negative_space_rule: {{negative_space_rule}}

## Hero Object (optional)
{{#if hero_object_mode}}
A hero product image is attached. Treat it as the **Hero Object**:
- preserve geometry and markings
- integrate it physically into the scene (correct lighting + shadows)
- do not invent brand wordmarks beyond what exists on the reference object
{{/if}}

## Text Mode
text_mode: {{text_mode}}  (BrandSafe Overlay | In‑Image Headline)

{{#if in_image_headline}}
Render this headline **inside the scene** on a physical surface (sign / phone screen / paper).  
Headline: {{headline_text}}

Rules:
- must be legible
- must be physically plausible (perspective + lighting)
- do NOT place floating overlay text
{{/if}}

## Global constraints
- Produce **one single full‑frame** image (no collage, no grids, no split-screen).
- No watermarks.
- No invented logos.

Generate 1 image.
