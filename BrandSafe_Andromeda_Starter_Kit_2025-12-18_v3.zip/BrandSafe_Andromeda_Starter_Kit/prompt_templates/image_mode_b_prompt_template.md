# Mode B — Reference Edit Prompt Template (v3)
Use this as the **user prompt** for image editing.

Assumptions:
- The reference creative image is attached as inlineData.
- Optionally, a **Protection Overlay Map** image is also attached (same image with highlighted protected zones).

---

You are editing the provided image to create a **brand‑safe variation**.

## What MUST stay the same
- Preserve ALL existing logos/wordmarks and existing marketing text.
- Preserve any product/packaging identity.
- Preserve the overall layout (do not redesign the ad).

If you are unsure whether something is a logo or text, DO NOT change it.

## What you MAY change (only these)
- Background: {{change_background_to}}
- People: {{change_people_to}}
- Style: {{visual_style}}

## Protected regions
Treat highlighted / described regions as **locked**:
{{protected_regions_description}}

## Output rules
- Maintain aspect ratio {{aspect_ratio}} exactly.
- Produce **one single full‑frame** image (no collage/grids).
- Do not add new logos or new text.

Return 1 edited image.
