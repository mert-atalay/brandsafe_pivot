# MASTER PROMPT — Build BrandSafe Andromeda Studio from scratch (v2, 2025-12-17)

**Use this prompt inside Google Antigravity.**
Recommended agent model: **Claude Opus 4.5**.

Goal: ship a working **Meta-first MVP** for SMBs that generates **brand-safe ad packs** (copy + images) with **Andromeda-style diversification**, plus **scoring** and **compliance**.

---

## 0) Instructions to the Agent

You are a senior full-stack engineer + product builder.

You MUST:
- Read **all docs** in `/docs` before coding.
- Implement the MVP in small, verifiable steps.
- Prefer correctness + debuggability over cleverness.
- Keep generation deterministic and testable where possible.
- Run Gemini calls **server-side (FastAPI)** so keys aren’t in the browser.
- In Mode A, generate **background plates only** (no AI logos, no AI text). We composite those ourselves.

You MUST NOT:
- Copy Pencil UI 1:1. Use it as *vibe inspiration*, but build an original interface.

---

## 1) What to build

Build a **monorepo** with:
- `apps/web` → React + Vite + TypeScript (UI)
- `apps/api` → Python FastAPI (async) (Gemini calls, compositing, scoring, storage)
- `packages/shared` → shared types (optional)

Storage:
- MVP: local disk under `apps/api/storage/`
- Optional: Supabase toggle later

Reference specs:
- Product + scope: `docs/PRODUCT_VISION.md`, `docs/PRD_MVP.md`
- Diversification: `docs/ANDROMEDA_CREATIVE_RULES.md`, `docs/CREATIVE_PATTERNS_LIBRARY.md`
- Prompting: `docs/GENAI_PROMPTING_SPEC.md`
- Brand kit: `docs/BRAND_KIT_SPEC.md`
- Templates/safe zones: `docs/TEMPLATE_SAFE_ZONES.md` + `/templates/*.json`
- Scoring: `docs/AD_SCORING_SPEC.md`
- Compliance: `docs/COMPLIANCE_GUARDRAILS.md`
- Export naming: `docs/EXPORT_FORMATS_SPEC.md`

---

## 2) Core user flows (MVP)

### Flow A — Brand Library (context learning)
Screen: **Brand Library**
- Brand name
- Upload logo(s)
- Upload 5–10 reference images (product + best ads)
- Brand colors (chips)
- Brand voice (adjectives + do/don’t)

Persist as `BrandKit`.

### Flow B — Generate Pack (main workflow)
Screen: **Generate Pack**
Inputs (left panel):
- Objective: Lead / Sales / Awareness
- Placements: 1:1, 4:5, 9:16, 16:9
- Offer + CTA
- Audience signals (chips + freeform)
- Pack size (8–12 default)
- Diversity threshold (0.6–0.85 default 0.70)
- Model preference (Pro default, Fast optional)

Output (right panel):
- Variant grid with thumbnails
- Each card shows:
  - Hook angle + scene pattern
  - Score (0–100) + 3–6 “why” bullets
  - Warning badges
  - Actions: Regenerate / Download / Mark Winner

### Flow C — Reference Edit (variations)
Screen: **Reference Edit**
- Upload a reference creative (PNG/JPG)
- Placement selector
- Protected zones:
  - default template zones
  - simple rectangle editor (optional)
- Edit knobs:
  - background (season/setting/time)
  - people (swap / remove / keep)
  - style (UGC / studio / premium)

Generate 4–8 variations.

---

## 3) The “Gold Layer” architecture (MUST IMPLEMENT)

Implement the intermediate abstraction layer:

1) `SegmentSignals` (raw inputs from UI)
2) `CreativeBrief` (sanitized + structured)
3) `PromptSpec` (rendered prompt strings + config)
4) `GenerationResult` (raw outputs)
5) `CompositedAsset` (final PNGs)

This prevents over-literal outputs and keeps everything consistent.

---

## 4) Gemini models + config (must match official docs)

### Models
- Copy: `gemini-3-pro-preview`
- Image Pro: `gemini-3-pro-image-preview`
- Image Fast fallback: `gemini-2.5-flash-image`

### Image config rules
- Use colon aspect ratios: `"1:1"`, `"4:5"`, `"9:16"`, `"16:9"` (do NOT convert to “/”)
- Use `imageSize` for Pro when needed: `"1K"` default; optionally `"2K"`
- Prefer `responseModalities: ["IMAGE"]`
- Auto fallback: if Pro fails, retry once with Fast

### Reference image MIME
- For data URLs, extract mimeType from the prefix
- Use `inlineData: { mimeType, data }` where `data` is base64 without the header

---

## 5) Deterministic brand compositing (the “BrandSafe” core)

Implement compositing in the API using Pillow:
- Templates define zones: `logo_zone`, `headline_zone`, `cta_zone`, etc.
- Place logo from BrandKit into `logo_zone`
- Render text using brand colors + typography defaults
- Export exact template resolution PNG

### Zone‑Lock Overlay (Mode B)
After Gemini edits the reference image:
- Overlay original protected regions on top of the edited output
- This guarantees logo/text is pixel-perfect preserved.

---

## 6) Diversification enforcement (must feel real)

A pack must contain meaningful variety across:
- Hook angles (8-angle set)
- Scene patterns (from `CREATIVE_PATTERNS_LIBRARY`)
- Setting/people/camera/lighting
- Copy similarity threshold

Implement:
- `diversityScore(pack) -> 0..1`
- Regenerate variants until score ≥ threshold or attempts == 3

---

## 7) Scoring + compliance (MVP confidence)

Implement per-variant:
- Score (0–100) using `docs/AD_SCORING_SPEC.md`
- Warnings using `docs/COMPLIANCE_GUARDRAILS.md`

Show these in the UI.

---

## 8) Deliverables & Acceptance Tests

### Deliverables
- Working UI: Home, Brand Library, Generate Pack, Reference Edit
- FastAPI endpoints per `docs/API_SPEC.md`
- Template system works for 4 Meta sizes
- Export zip follows `docs/EXPORT_FORMATS_SPEC.md`

### Acceptance tests (manual)
- Generate Pack creates 8+ variants with real angle+pattern diversity
- Mode A: backgrounds contain no text/logos; overlays come from compositor
- Mode B: reference edits keep logo/text unchanged (Zone‑Lock works)
- Score + warnings render in UI
- Pro default + Fast fallback works

---

## 9) Implementation order (recommended)
1. Repo scaffold + dev scripts
2. Templates + compositor
3. Brand Library CRUD
4. Gemini copy + image Mode A
5. Pack generator (angles+patterns+diversity)
6. Reference edit + Zone‑Lock
7. Scoring + compliance
8. UX polish + export

---

## 10) Phase 2 (plan ahead, don’t build now)
- Video generation via Veo (`docs/VIDEO_ROADMAP.md`)
- Performance feedback loop (mark winners, later ingest Meta results)
