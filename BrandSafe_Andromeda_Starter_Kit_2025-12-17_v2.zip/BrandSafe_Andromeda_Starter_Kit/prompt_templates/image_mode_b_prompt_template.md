You are editing the provided image to create a brand-safe variation.

MUST:
- Preserve ALL existing text, logos, brand marks, and product details.
- If you are unsure whether something is a logo/text, DO NOT change it.
- Only change: background and people (if requested).
- Keep composition and framing consistent.
- Output image in aspect ratio {{aspect_ratio}}.

Edits:
- change_background_to: {{change_background_to}}
- change_people_to: {{change_people_to}}
- style: {{visual_style}}
- keep_these_regions_unchanged: {{protected_regions_description}}

Return 1 edited image.
