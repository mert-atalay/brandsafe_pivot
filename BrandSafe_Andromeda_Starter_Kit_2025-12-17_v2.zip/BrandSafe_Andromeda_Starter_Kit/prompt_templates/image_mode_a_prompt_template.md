You are generating a PHOTO-REALISTIC AD BACKGROUND PLATE.

Goal: Create a visually compelling background scene that supports an ad.
IMPORTANT: The final logo + text will be added later by a compositor.

MUST:
- NO visible text, NO logos, NO watermarks, NO brand names.
- No readable signage.
- Leave clean NEGATIVE SPACE for overlay text in the {{negative_space_region}}.
- Match aspect ratio {{aspect_ratio}} exactly.

CreativeBrief:
- hook_angle: {{hook_angle}}
- scene_pattern: {{scene_pattern}}
- audience_signals: {{audience_signals}}
- offer_theme: {{offer_theme}}
- pattern_cues: {{pattern_cues}}
- visual_style: {{visual_style}}
- setting: {{setting}}
- people: {{people}}
- camera: {{camera}}
- lighting: {{lighting}}
- composition: {{composition}}

Generate 1 image.
