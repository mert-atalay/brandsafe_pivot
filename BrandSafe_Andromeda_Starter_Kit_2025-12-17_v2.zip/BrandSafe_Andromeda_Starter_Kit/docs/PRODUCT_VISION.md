# Product Vision — BrandSafe Andromeda Studio (Meta-first)

## One sentence
Generate **brand-safe, Meta-ready creative packs** (image + copy) that are **genuinely diversified** for the Andromeda-era delivery environment, using Google Gemini (Nano Banana Pro) as the core generation engine.

## Who it’s for (explicit)
Primary:
- **SMBs** who run Meta ads but don’t have a creative team
- **Small agencies / freelancers** producing ads for multiple local clients

Not primary:
- Large enterprise creative ops teams (Typeface-style workflows are better there)

## The promise (what makes it “must-use”)
1) **On-brand by default**
   - logos and text are never re-drawn by the model
   - templates enforce layout + safe zones

2) **Real diversification**
   - a pack is not 8 tiny tweaks
   - it is 8–12 distinct concepts (angles + scenes + formats)

3) **Fast iteration loop**
   - generate → pick 2–3 winners → export → repeat next week

4) **Guidance, not just outputs**
   - each creative gets a **Score (0–100)** + simple reasons
   - basic compliance checks reduce “ad rejected” frustration

## What “brand-safe” means here
- Gemini generates **background scenes + people** (or edits only allowed regions).
- The app deterministically adds:
  - logo
  - headline/subhead/CTA text
  - brand colors + typography
  - placement templates & safe zones

## Why this matters in 2025
Meta’s ad delivery is increasingly driven by retrieval + automation, which rewards **creative portfolios**, not single “best” ads. The product exists to make creating that portfolio easy for small teams.
