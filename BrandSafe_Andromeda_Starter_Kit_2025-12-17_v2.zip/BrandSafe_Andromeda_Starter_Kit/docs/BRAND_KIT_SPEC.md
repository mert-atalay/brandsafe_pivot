# Brand Kit Spec (v2)

The Brand Kit is the center of “context learning.”
We are not fine-tuning in MVP; we are conditioning on saved brand assets.

## BrandKit fields
- `brand_id`
- `brand_name`
- `website_url` (optional)

### Visual identity
- `logos[]`: `{ id, name, file_url, preferred_background: 'light'|'dark'|'transparent' }`
- `colors[]`: `{ name, hex }`
- `fonts[]`: `{ name, file_url }` (optional MVP)

### Context learning assets
- `reference_images[]`: product photos + lifestyle imagery (5–10 recommended)
- `winning_ads[]`: optional (past best ads) — can be part of reference_images in MVP

### Voice
- `voice.adjectives[]` (3–6)
- `voice.do[]`
- `voice.dont[]`

### Compliance notes (optional)
- `approved_claims[]`
- `disallowed_claims[]`

## Extraction helpers (post-MVP)
- Auto-extract colors from logo
- Auto-extract typography from website
- Auto-extract value props from landing page

## Rules (brand-safe)
- Logos are placed by compositor only.
- Overlay text is rendered by compositor only.
- Gemini may see reference images to learn “look + product identity,” but prompts must forbid generating logos/text.
