# UI/UX Spec (v2) — inspired by Pencil, built for SMB speed

## Design goals
- Clean, spacious, card-based
- Feels like: “upload brand → generate ad pack → export”
- Minimal jargon. No prompt engineering required.
- Preview-first: results appear immediately, not hidden behind tabs.

## Navigation (MVP)
Left nav:
- Home
- Brand Library
- Generate Pack
- Reference Edit
- Video (Coming soon)

Top bar:
- Brand selector
- Export actions (when in a pack)

## Screen details

### 1) Home
- “Start from scratch” cards:
  - **Generate Pack** (primary)
  - Reference Edit
  - Brand Library
- Recent packs list (last 10)

### 2) Brand Library
Purpose: context learning assets per brand.
- Upload logo(s)
- Upload 5–10 reference images (product + best ads)
- Brand colors chips (manual)
- Brand voice (adjectives + do/don’t)
- Save

### 3) Generate Pack (main)
Layout: left inputs, right results.

Left inputs (keep short):
- Objective (Lead / Sales / Awareness)
- Placements (1:1, 4:5, 9:16, 16:9)
- Offer / CTA (two fields)
- Audience signals (chips + freeform)
- Pack size (8–12)
- Diversity threshold slider (0.6–0.85)
- Model preference: Pro / Fast (defaults Pro)

Right results:
- Grid of Variant Cards
- Each card shows:
  - thumbnail
  - hook angle + scene pattern
  - score (0–100)
  - warnings badges
  - quick actions: “Regenerate”, “Mark Winner”, “Download”

### 4) Reference Edit
- Upload reference creative
- Placement selector (auto-detect if possible)
- Protected zones:
  - default template zones
  - optional rectangle editor
- Edits:
  - background: (season, setting, time)
  - people: (swap / remove / keep)
  - style: (UGC / studio / premium)
- Generate variations (4–8)

### 5) Video (Phase 2)
- Disabled with “Coming soon” panel.
- Show what it will do:
  - animate a winning static creative
  - generate short 8s clips with Veo

## Why we show angles + patterns
We surface angle + pattern in the UI so users understand why packs matter, and can quickly rotate strategy.

## Accessibility & usability
- Always allow vertical scrolling in results areas.
- Sticky left panel inputs, scrollable right results grid.
- Never hide generated assets below the fold without scroll.
