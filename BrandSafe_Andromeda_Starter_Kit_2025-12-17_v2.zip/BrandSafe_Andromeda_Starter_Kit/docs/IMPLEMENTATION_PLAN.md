# Implementation Plan (v2)

This plan is ordered to get a usable Meta-first MVP fast, without painting us into a corner.

## Phase 0 — Repo + CI sanity (Day 0)
- Monorepo scaffold: `apps/web` (Vite React TS) + `apps/api` (FastAPI)
- One command to run both (dev script)
- Local file storage (`apps/api/storage/`)
- Smoke tests (API health route, basic UI render)

## Phase 1 — Templates + compositor (MVP backbone)
- Implement Template JSON spec (4 Meta sizes)
- Implement Pillow compositor:
  - logo placement
  - text rendering (headline, CTA)
  - safe-zone collision detection
- Implement export zip naming per `docs/EXPORT_FORMATS_SPEC.md`

## Phase 2 — Brand Library (context learning)
- BrandKit CRUD:
  - logo(s)
  - colors
  - voice
  - reference images (5–10)
- Store brand reference images and retrieve for generation calls

## Phase 3 — Generation (copy + image)
- Copy generation endpoint:
  - strict JSON outputs
  - angle + pattern aware
- Image Mode A endpoint:
  - Pro default (`gemini-3-pro-image-preview`)
  - Fast fallback (`gemini-2.5-flash-image`)
  - enforce aspect ratio + image size
- Image Mode B endpoint:
  - reference image MIME detection
  - prompt constraints to preserve text/logo

## Phase 4 — Pack generator + diversification enforcement
- Implement “PackSpec” → list of variants:
  - each variant = hook angle + scene pattern
- Generate background plates + copy per variant
- Enforce diversity score with limited regen attempts
- Surface diversity score in UI

## Phase 5 — Zone‑Lock Overlay (reference edit perfection)
- Extract protected zones from template
- After Mode B edit, overlay protected regions from original image
- Verify pixel-perfect logo/text preservation

## Phase 6 — Scoring + compliance (MVP confidence)
- Implement score (0–100) per `docs/AD_SCORING_SPEC.md`
- Implement compliance checks per `docs/COMPLIANCE_GUARDRAILS.md`
- Show reasons + warnings in UI

## Phase 7 — UX polish
- Scrollable results grid
- Fast regenerate + “mark winner”
- Export all assets

## Phase 8 — Phase 2 (video)
- Add `Video` tab and backend scaffolding for Veo (see `docs/VIDEO_ROADMAP.md`)
- Do not build full editor; generate + export only
