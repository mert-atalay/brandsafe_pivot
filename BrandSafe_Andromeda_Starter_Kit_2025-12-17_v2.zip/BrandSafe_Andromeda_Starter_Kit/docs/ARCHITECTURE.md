# Architecture (MVP, Meta-first)

## Stack
- Frontend: React + Vite + TypeScript
- Backend: Python FastAPI (async)
- Storage: Local filesystem (MVP), Supabase Storage optional
- DB: Optional (Supabase Postgres) for brands + packs + feedback

## High-level flow
Web app → FastAPI → (Gemini text + image) → compositing → scoring/compliance → storage → web previews/export

## Why server-side generation
- Do not expose API keys in the browser
- Central retries + fallback logic
- Centralized logging, rate limiting, caching
- Enables future features (video LRO operations, webhooks, performance ingestion)

## Backend modules (suggested)
- `generation/`
  - `copy.py` (Gemini text → JSON)
  - `image.py` (Gemini image Mode A/B + fallback)
  - `pack.py` (angles + patterns + diversity enforcement)
  - `reference_edit.py` (Mode B helper)
- `compositor/`
  - `templates.py` (load template JSON)
  - `render.py` (Pillow compositing)
  - `zone_lock.py` (restore protected pixels)
- `scoring/`
  - `score.py` (heuristic score + optional critic)
- `compliance/`
  - `checks.py` (claims + overflow + similarity warnings)
- `storage/`
  - `local.py`
  - `supabase.py` (optional)
- `video/` (Phase 2)
  - `veo.py` (generateVideos + polling)

## Frontend modules (suggested)
- `pages/Home` (start cards + recent packs)
- `pages/BrandKit` (brand library)
- `pages/AdsPack` (campaign builder + results)
- `pages/ReferenceEdit`
- `pages/Video` (disabled until Phase 2)
- shared components:
  - `PreviewGrid`
  - `VariantCard` (score + warnings)
  - `ZoneEditor` (simple rectangles)

## Data model highlights
- BrandKit:
  - logo(s), colors, voice, reference_images[]
- PackSpec:
  - placements[], pack_size, diversity_threshold
  - hook_angle_preset, scene_pattern_preset
- Variant:
  - hook_angle, scene_pattern
  - background_plate_id, composited_image_ids[]
  - copy_json
  - score + warnings
