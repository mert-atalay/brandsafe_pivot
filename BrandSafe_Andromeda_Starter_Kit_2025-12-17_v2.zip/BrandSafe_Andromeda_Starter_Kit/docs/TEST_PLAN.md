# Test Plan (MVP, v2)

## Unit tests (API)
- Template loader validates zones within bounds
- Compositor places logo within padding
- Compositor text rendering respects safe zones
- Zone‑Lock Overlay merges protected pixels exactly
- Copy validator rejects non‑JSON outputs
- Compliance checker flags risky claims
- Diversity scorer penalizes near-duplicates

## Integration tests
- POST `/generate/pack` returns expected variant count
- Pro model failure triggers fallback once (then succeeds or errors cleanly)
- Returned image dimensions match template exactly
- Reference edit works with JPG and PNG inputs (MIME detection)
- Export zip contains images + copy + manifest with correct naming

## Manual checks
- Mode A images contain no text/logos (plate only)
- Reference edit preserves logo/text regions pixel-perfect (within tolerance)
- Pack contains real variety (angle + pattern)
- UI results grid scrolls; previews are not hidden below the fold
