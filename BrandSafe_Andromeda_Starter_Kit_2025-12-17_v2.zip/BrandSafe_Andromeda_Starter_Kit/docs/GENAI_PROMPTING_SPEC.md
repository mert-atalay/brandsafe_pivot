# GenAI Prompting Spec (Gemini / Nano Banana Pro)

This document defines **how we prompt** and **how we configure** Gemini calls so outputs are:
- on-brief
- brand-safe
- consistent across variants
- compatible with Gemini 3 Pro Image (Nano Banana Pro)

## Models (Dec 2025)
- **Text**: `gemini-3-pro-preview` (default)
- **Image Pro** (Nano Banana Pro): `gemini-3-pro-image-preview` (default)
- **Image Fast**: `gemini-2.5-flash-image` (fallback + optional toggle)

## Core philosophy (non-negotiable)
1) **Never ask Gemini to draw the logo**.
2) **Never ask Gemini to write brand names or marketing text inside the image**.
   - Exceptions only if the product later adds an explicit “AI text inside image” mode.
3) Always go through the intermediate layer:
   `SegmentSignals → CreativeBrief → PromptSpec → GenerationResult → CompositedAsset`

## Gemini config (critical)
### Image generation / edit config
- Aspect ratios MUST use **colon format**: `"1:1"`, `"4:5"`, `"9:16"`, `"16:9"`
- Use `imageSize` for Pro when needed: `"1K"` (default), `"2K"`, `"4K"`
- Prefer `responseModalities: ["IMAGE"]` for production
  - optionally include `"TEXT"` in dev/debug

**JS shape (Google GenAI SDK)**
```js
const resp = await ai.models.generateContent({
  model: "gemini-3-pro-image-preview",
  contents: [{ role: "user", parts: contentParts }],
  config: {
    responseModalities: ["IMAGE"],
    imageConfig: {
      aspectRatio: "4:5",
      imageSize: "1K"
    }
  }
});
```

### Multi-image conditioning (“temporary LoRA”)
When a brand has reference images:
- attach up to **10 images** for Pro (3 for Fast)
- tell the model: “Use these as style/product reference only.”
- do NOT request logo/text replication.

## Mode A — New Creative (background plate)
**Goal:** Generate a high-quality **background plate** that leaves negative space where our compositor will place logo/text.

Required constraints:
- no text
- no logos
- no brand names
- no UI overlays
- no watermarks or fake badges

Prompt structure:
1) Scene intent (what the ad should feel like)
2) Setting + people + action
3) Camera + lighting + composition
4) Negative space instruction (where overlay will go)
5) Hard constraints (no text/logos)

## Mode B — Reference Edit (background + people swap)
**Goal:** Edit ONLY allowed areas; then API overlays original protected pixels.

Prompt structure:
1) “Edit this image.”
2) “Preserve everything except background + people.”
3) “Do not change any existing text/logo/product.”
4) Specific edit instruction: season, setting, people swap, mood

Implementation note:
- Even if Gemini changes protected pixels slightly, we restore them with Zone‑Lock Overlay.

## Copy generation (structured JSON)
Always request strict JSON:
- `headlines[]` (<= 40 chars, Meta-friendly)
- `primary_texts[]` (short/standard/long preset)
- `ctas[]` (optional)
- `hook_angle`
- `scene_pattern`
- `compliance_notes[]`

## Auto-fallback rules
- Pro fails? Retry once with Fast.
- Fast fails? Return a clear error message and log the request id.

## Evaluation prompts (optional but recommended)
Use Gemini as a *critic* (text-only) to:
- score hook strength
- detect risky claims
- detect near-duplicate copy

See `docs/AD_SCORING_SPEC.md`.
