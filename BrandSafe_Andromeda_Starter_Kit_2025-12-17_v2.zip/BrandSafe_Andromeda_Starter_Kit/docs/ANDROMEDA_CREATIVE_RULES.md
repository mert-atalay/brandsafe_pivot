# Andromeda-era Creative Rules (practical, enforced)

> “Andromeda” is used here as shorthand for the current Meta delivery environment where
> retrieval + ranking + automation work best when you give the system a **portfolio** of meaningfully different creatives.

## Core idea
A pack should NOT be “the same ad 8 times.”
Minor edits (colors, tiny copy tweaks) are treated as near-duplicates and waste impressions.

**Target pack size**
- MVP default: **8–12**
- Target by Phase 2: **12–15**

## What counts as a “different creative”
A variant must change at least **2** of these primary levers:
1) **Hook angle** (message)
2) **Scene pattern** (visual story format)
3) **Setting/context** (environment)
4) **People/story** (who + what they’re doing)
5) **Format** (static vs motion, or at least different placement/layout)

If you only change *one* lever, you are probably creating duplicates.

## Hook angles (starter set)
Keep the list small and understandable for SMBs:
1. Attention / pattern break
2. Local relevance (optional)
3. Social proof / trust
4. Problem → solution
5. Benefits / outcomes
6. Authority / credibility
7. Offer / urgency (soft)
8. Education / “how it works”

> Vertical-specific angles (e.g., Montessori) should live in a brand-specific “angle presets” list,
> not hard-coded as a global default.

## Scene patterns library (MVP)
Each variant should also pick a **scene pattern** (see `docs/CREATIVE_PATTERNS_LIBRARY.md`):
- UGC selfie testimonial
- Founder / expert talking-head
- Before/after transformation
- Routine / day-in-the-life
- Product-in-use demo
- Infographic / diagram style
- “Problem headline” poster style

## Visual diversification checklist
Use as a hard checklist when generating packs:
- Setting: home, workplace, outdoors, in-store, studio
- People: none / single / group; candid vs posed; age diversity
- Camera: wide, mid, close-up, POV
- Lighting: daylight, warm indoor, golden hour
- Composition: negative space for overlay text; rule-of-thirds; centered
- Texture: UGC phone photo vs polished studio

## Copy diversification checklist
- First 5 words must differ across variants
- Different promise framing (save time, save money, feel confident, look professional)
- Different objections handled (trust, price, time, uncertainty)
- Different CTAs (Book, Get quote, Learn more, Shop now)

## Diversity scoring (MVP)
Compute score 0–1 from:
- hook angle uniqueness (required)
- scene-pattern uniqueness (required)
- copy similarity (semantic OR n-gram)
- visual descriptor overlap (keywords)

**Enforcement**
Regenerate individual variants until:
- score >= threshold (default 0.70)
- OR attempts == 3

Always surface the diversity score in the UI so users understand why packs matter.
