# Brand/Product “Tuning” Strategy

You want the generator to consistently reproduce the same brand/product look without hallucinating.

## Method A — In-context “Temporary LoRA” (DO THIS NOW)
Every generation call can include **5–10 reference images**:
- product photos
- previous winning ads
- brand lifestyle imagery

The model visually conditions on these images and will usually match:
- product geometry
- packaging
- materials
- brand style

Implementation:
- Store reference images in BrandKit (“brandRefs”)
- For each generation call, attach up to N images (N=10 for Pro, N=3 for Flash) along with the prompt.
- The prompt must say: “Use these as style/identity reference. Do not add logos or text.”

## Method B — Vertex AI Subject Tuning (LATER)
Use Vertex AI “subject tuning” / fine-tuning flow to train a specialized model for a brand/product.
Pros: most consistent
Cons: costs time + money, operational overhead

MVP stance:
- Ship with Method A.
- Keep the code structured so Method B can plug in later (swap model id).
