# Integrations Backlog (post-MVP)

- Meta Ads account connect (pull top ads + learnings)
- Google Ads connect
- GA4 connect (landing page + conversion signals)
- Canva connect (pull brand assets)
- Vertex AI Subject Tuning for brand/product consistency
