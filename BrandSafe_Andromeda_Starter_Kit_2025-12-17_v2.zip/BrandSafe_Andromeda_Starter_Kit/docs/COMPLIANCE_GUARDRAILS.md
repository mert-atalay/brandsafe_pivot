# Compliance & Brand-Safety Guardrails (MVP)

BrandSafe is not “no rules.” It is **rules first**.
This document defines guardrails for:
- prompt generation
- copy generation
- compositing
- output checks

## High-level rules (always)
1) Do not generate or encourage disallowed content.
2) Do not use deceptive claims.
3) Don’t impersonate real people or brands.
4) Don’t generate sensitive personal data.

## Copy guardrails
### Prohibited / risky claims (warn or block)
- Guaranteed results (“guaranteed”, “100%”, “instant cure”)
- Health/medical claims unless user provides compliant approved wording
- Financial promises (“make $10k/week”)
- Superlatives without proof (“#1”, “best in the world”) unless user provides substantiation

### Style guardrails
- Avoid shaming, fearmongering, or manipulative language
- Avoid political/controversial targeting language unless explicitly requested and allowed

## Image guardrails
### In Mode A (new creative)
- No text inside the generated image
- No logos, brand marks, or watermarks
- No brand names
- No readable signage in the environment

### In Mode B (reference edit)
- Do not alter:
  - existing logo
  - existing text
  - product/packaging identity
- Allowed changes:
  - background
  - people (if the product allows)
  - lighting/mood (within reason)

## Platform safety (Meta-first)
MVP checks should warn on:
- text overlay that invades safe zones
- tiny unreadable text
- aggressive urgency language (spammy)

We do NOT attempt to bypass platform review systems.

## Enforcement approach
- **Before generation**: prompt guardrails (reject risky inputs)
- **After generation**: output checks
  - copy risk scanner (regex + critic model)
  - similarity check within pack
  - layout collision check (zones)

## Logging
Log only what’s needed to debug:
- request id
- model id
- config
- short hashed representation of prompts (optional)
Never log raw API keys.
