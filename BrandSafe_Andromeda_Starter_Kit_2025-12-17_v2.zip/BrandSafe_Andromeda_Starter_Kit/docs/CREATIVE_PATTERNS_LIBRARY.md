# Creative Patterns Library (MVP)

This library exists to make “diversification” concrete.
Instead of generating 8 random images, each variant is:
- one **hook angle** (message)
- plus one **scene pattern** (visual story format)

Each pattern below includes:
- Best use
- What the background plate should depict
- Prompt cues (Mode A)
- Notes for Mode B (reference edit)

> IMPORTANT: In Mode A, we do **background plates only** (no text, no logos). Text/logo are composited later.

---

## Pattern 01 — UGC Selfie Testimonial
**Use when:** Trust/social proof is key, SMB/local services, D2C.

**Plate depicts:** Person holding/using the product in a real environment; casual phone-photo vibe; natural lighting.

**Prompt cues:**
- “candid smartphone photo, slight motion blur, authentic”
- “subject looking into camera, friendly expression”
- “leave clean negative space at top/bottom for overlay copy”

**Mode B:** Swap background season/location; keep face region stable if possible.

---

## Pattern 02 — Founder / Expert Talking-Head
**Use when:** Credibility and authority matter.

**Plate depicts:** A professional person speaking to camera in a simple setting (office, studio, classroom).

**Prompt cues:**
- “mid shot, shallow depth of field, clean backdrop”
- “professional but warm”
- “negative space on one side for overlay”

**Mode B:** Keep framing; replace background or wardrobe tone.

---

## Pattern 03 — Product In-Use Demo
**Use when:** You need to show how it works (tactile products, services).

**Plate depicts:** Hands using the product; action-driven; clear focus on the “moment.”

**Prompt cues:**
- “close-up hands, action moment, crisp focus”
- “clean background, negative space for CTA bar”

**Mode B:** Change environment or hands (diversity) without touching product.

---

## Pattern 04 — Before / After (Transformation)
**Use when:** Clear transformation is a key promise.

**Plate depicts:** Split scene look OR a single frame that implies change (we handle text overlays).

**Prompt cues:**
- “two-panel composition feel with a clear separation”
- “consistent lighting across both halves”
- “simple background; leave space for labels”

**Mode B:** Adjust lighting/scene to match reference.

---

## Pattern 05 — Routine / Day-in-the-life
**Use when:** Lifestyle and habits drive purchase.

**Plate depicts:** Morning routine, desk setup, family moment, etc.

**Prompt cues:**
- “lifestyle scene, natural light, authentic, warm”
- “wider shot with negative space for headline”

---

## Pattern 06 — Social Proof Collage (No text inside image)
**Use when:** You have real reviews/testimonials.

**Plate depicts:** A clean “photo collage” background plate (no text), with empty card shapes where we will render review quotes.

**Prompt cues:**
- “blank rounded-rectangle cards arranged as a collage, no text”
- “soft shadows, clean modern design”

**Mode B:** Keep card layout; swap background texture.

---

## Pattern 07 — Offer Poster (Design-first)
**Use when:** Promotions or announcements need impact.

**Plate depicts:** Minimal design plate with strong color field + product silhouette/photo area; we add text.

**Prompt cues:**
- “minimal poster background, bold shapes, modern, no text”
- “large empty space for headline, CTA zone”

---

## Pattern 08 — Infographic / Diagram Plate (No text)
**Use when:** Education angle; complex value prop.

**Plate depicts:** Diagram-like shapes (arrows, boxes) without any text.

**Prompt cues:**
- “clean diagram layout with arrows and boxes, no text”
- “white background with subtle brand-color accents”

---

## Pattern 09 — Local / Nearby Context
**Use when:** Local relevance is a core hook.

**Plate depicts:** A recognizable “local vibe” background (not necessarily a landmark), e.g. neighborhood scene.

**Prompt cues:**
- “subtle city/suburb environment, friendly, safe”
- “avoid text signage; no readable street signs”

---

## Pattern 10 — Premium / Luxury Product Shot
**Use when:** High-end brands, polished aesthetic.

**Plate depicts:** Studio-style product plate with dramatic lighting and clean gradients.

**Prompt cues:**
- “studio lighting, premium, high contrast, crisp”
- “negative space for brand headline”

---

## Using patterns in packs
**Pack rule:** each creative must have a unique combo of:
- hook angle
- scene pattern

A default 8-pack could be:
1) Attention + Offer Poster
2) Trust + UGC Testimonial
3) Benefits + Product In-Use Demo
4) Authority + Founder Talking Head
5) Education + Diagram Plate
6) Problem→Solution + Before/After
7) Local + Nearby Context
8) Outcomes + Routine

