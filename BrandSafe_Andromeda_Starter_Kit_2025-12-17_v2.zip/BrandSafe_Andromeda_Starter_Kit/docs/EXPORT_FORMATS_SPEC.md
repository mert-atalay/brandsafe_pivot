# Export Formats Spec (MVP)

Goal: make it effortless to hand off assets to a media buyer or upload to Meta.

## Export bundle
When the user clicks **Export Pack**, generate a zip with:

```
BrandSafe_<brand>_<campaign>_<YYYYMMDD>_<packId>.zip
  /images/
    <variantId>__<hookAngle>__<scenePattern>__1x1.png
    <variantId>__<hookAngle>__<scenePattern>__4x5.png
    <variantId>__<hookAngle>__<scenePattern>__9x16.png
    <variantId>__<hookAngle>__<scenePattern>__16x9.png
  /copy/
    <variantId>.json
  /meta/
    pack_manifest.json
    summary.csv
```

## copy/<variantId>.json
Contains:
- headline
- primary_text
- description (optional)
- cta
- hook_angle
- scene_pattern
- audience_signals (abstracted)
- score_0_100
- compliance_warnings

## pack_manifest.json
Contains pack-level metadata:
- brand_id
- created_at
- placement_sizes
- diversity_threshold
- generation_models (pro/fast)

## summary.csv
One row per variant:
- variant id
- hook angle
- scene pattern
- score
- file names

