# PRD — MVP Requirements (v2)

## Top priority outcomes
1. Generate a **Meta creative pack** (images + copy) that is:
   - immediately usable
   - genuinely diversified (Andromeda-era)
   - on-brand and platform-safe by construction
2. Generate **reference edits** that preserve existing logo/text pixels perfectly.
3. Give SMB users **confidence** via a simple score + compliance checks.

## MVP scope (what we build first)
### In scope (must-have)
- Brand Kit onboarding
  - upload logo(s)
  - brand colors (manual + optional auto-extract later)
  - brand voice (3–6 adjectives + do/don’t list)
  - Brand Library: upload 5–10 reference images (product + winning ads)
- Meta placements + templates
  - 1:1 (1080×1080)
  - 4:5 (1080×1350)
  - 9:16 (1080×1920)
  - 16:9 (1920×1080)
- **Generate Pack**
  - 8–12 variants default
  - each variant uses a different hook angle + scene pattern
  - outputs: final composited PNG + copy JSON
- **Reference Edit**
  - upload existing creative
  - choose what is allowed to change (background + people)
  - Zone‑Lock Overlay restores original protected pixels
- **Creative Score (0–100)** (MVP heuristic)
  - includes diversity + clarity + CTA strength + brand fit + safe-zone fit
- **Compliance checks (MVP)**
  - warns on risky claims (health, finance, guarantees)
  - warns on text overflow / unreadable overlay
  - warns on high similarity between variants
- Export
  - zip download with consistent naming
- Storage
  - local disk storage for MVP
  - Supabase optional toggle (auth + storage can be Phase 1.5)

### Nice-to-have (only if MVP is stable)
- “Winner marking” library (manual): user marks ads as winners/losers
- Copy length presets (short/standard/long) for primary text
- Simple template picker (3–5 layouts)

## Out of scope (post-MVP)
- Full billing
- Deep automated performance ingestion (Meta/Google APIs)
- Full Canva-style editor
- Full fine-tuning/LoRA training (use in-context reference images instead)

## Video (explicit plan)
- MVP: **do not block release for video**
- Phase 2: add Veo-based video (see `docs/VIDEO_ROADMAP.md`)

## Non-goals
- Not a Typeform/Typeface enterprise suite.
- Not copying Pencil UI 1:1.

## Key UX requirement
Everything should be “one decision per screen.”
If the user feels they need prompt engineering knowledge, we failed.
