# Ad Scoring Spec (MVP → Phase 2)

Goal: give SMB users a **simple, explainable score** so they can pick winners without being an ad expert.

## Output
Return:
- `score_0_100` (integer)
- `reasons[]` (3–6 short bullets)
- `warnings[]` (0+)

## MVP Scoring (heuristic + optional Gemini critic)
MVP uses deterministic checks and a lightweight text-only “critic” call.

### Score components (recommended weights)
1) **Diversity** (0–25)
   - is this variant meaningfully different from others in the pack?
   - penalize near-duplicate copy (n-grams / embeddings)
   - penalize repeated scene patterns

2) **Clarity** (0–25)
   - headline length reasonable (<= 40 chars)
   - primary text readable and not too long for placement
   - CTA present and clear

3) **Hook strength** (0–20)
   - first 5 words are specific and attention-grabbing
   - avoids generic fluff (“best”, “amazing”) unless supported
   - matches selected hook angle

4) **Brand fit** (0–15)
   - matches brand voice adjectives
   - avoids banned words / off-tone style

5) **Visual/layout fitness** (0–15)
   - overlay does not collide with safe zones
   - adequate negative space for text
   - correct aspect ratio

### Penalties (subtract)
- -10 to -40 for compliance risk (see `docs/COMPLIANCE_GUARDRAILS.md`)
- -10 if text overflows or is too small
- -5 if CTA is missing

## Gemini critic (recommended)
Use a **text-only** Gemini call to assess:
- is this a strong hook?
- does it feel like an ad?
- is it too generic?
- any risky claims?

Critic prompt should return strict JSON:
```json
{
  "hook_strength": 0-10,
  "clarity": 0-10,
  "brand_fit": 0-10,
  "risk_flags": ["..."]
}
```

Then map to scoring weights.

## Phase 2 Scoring (data-informed)
Once we ingest performance outcomes:
- train a lightweight model / calibration layer
- personalize scoring per brand and objective
- include benchmarks like “expected to outperform X% of your ads”

But do NOT block MVP on this.
