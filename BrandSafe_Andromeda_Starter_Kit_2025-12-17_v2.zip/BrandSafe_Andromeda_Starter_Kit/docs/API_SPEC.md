# API Spec (MVP, v2)

This is the backend contract the web app calls.
All Gemini calls happen on the server.

## Conventions
- JSON request/response
- Images returned as asset ids (files served via `/assets/{id}`)
- For MVP, store files on disk; later swap to Supabase.

## Health
### GET /health
Returns `{ ok: true }`.

## Brands
### POST /brands
Create a brand kit.

### GET /brands
List brands.

### GET /brands/{id}
Fetch brand kit.

### PUT /brands/{id}
Update brand kit.

### POST /brands/{id}/assets
Upload brand assets (logo, reference images).
Returns asset ids.

## Generation
### POST /generate/copy
Input: `{ brand_id, creative_brief }`
Output: `{ copy_variants[], warnings[] }`

### POST /generate/image
Input: `{ brand_id, prompt_spec, model_preference, aspect_ratio, image_size }`
Output: `{ background_plate_asset_id, model_used, warnings[] }`

### POST /generate/pack
Input: `{ brand_id, pack_spec }`
Output: `{ pack_id, variants[] }`

### POST /edit/reference
Input: `{ brand_id, reference_asset_id, edit_spec, placement, protected_zones }`
Output: `{ variants[] }`

## Scoring & compliance
Scoring is included inline in `variants[]`.
Optionally expose:
### POST /score
Input: `{ brand_id, variant }`
Output: `{ score_0_100, reasons[], warnings[] }`

## Assets
### GET /assets/{id}
Serves image/video file.

### GET /packs/{id}/export
Returns zip download.

## Video (Phase 2)
### POST /video/generate
Returns `{ operation_id }`

### GET /video/operation/{operation_id}
Returns status + video asset id when ready.
