# BrandSafe Andromeda Studio — Starter Kit (v2, 2025-12-17)

This folder is a **product + engineering spec pack** you can drop into an agentic builder (Google Antigravity / Cursor / Claude Code) to build a new app from scratch.

## What we’re building (the pivot)
A **Meta-first ad generation tool** for **SMBs + small agencies** that need:
- lots of *real* creative variety (Andromeda-era diversification)
- strict brand safety (logos + text never get “redrawn” by the model)
- fast iteration (generate → pick winners → export → learn)

## Core outputs (MVP)
A “creative pack” contains:
- **Images** in Meta-ready sizes (1:1, 4:5, 9:16, 16:9)
- **Copy** variants (primary text + headline + CTA)
- **Creative Score (0–100)** + simple “why” bullets
- **Compliance checks** (basic brand + platform guardrails)

## Two generation modes (non-negotiable)
- **Mode A — New Creative:**
  - Gemini generates a **background plate only** (no text, no logos, no brand names)
  - API composites logo + text deterministically using templates/safe-zones

- **Mode B — Reference Edit:**
  - User uploads an existing ad creative
  - Gemini edits **only background + people**
  - API applies **Zone‑Lock Overlay** to restore original logo/text pixels perfectly
  - Optional: “Replace Copy” uses compositor to re-render text (never AI text)

## “Context learning” (MVP-friendly)
We do **in-context conditioning** instead of fine-tuning:
- attach 5–10 reference images per brand (product + past winning creatives)
- store/retrieve these per user/brand in the Brand Library

## What’s inside
- `MASTER_PROMPT_ANTIGRAVITY_OPUS45.md` — the one prompt to build the repo
- `docs/` — product requirements + architecture + prompting + rules
- `prompt_templates/` — copy + image prompt templates
- `templates/` — placement templates + safe zones
- `assets/` — placeholder brand assets for testing + instructions
- `.env.example` — local env template

## Recommended build path
1) Build **static packs** + reference edits + scoring + compliance (Meta-first)
2) Add **Video (Phase 2)** with Veo (plan included)
3) Add account integrations + automated performance feedback loop
