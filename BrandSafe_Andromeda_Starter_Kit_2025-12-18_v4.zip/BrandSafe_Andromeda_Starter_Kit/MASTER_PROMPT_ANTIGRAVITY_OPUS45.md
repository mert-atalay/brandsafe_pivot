# MASTER PROMPT — Build **BrandSafe Andromeda Studio** from scratch (v4, 2025‑12‑18)

**Use this prompt inside Google Antigravity.**  
Recommended agent model: **Claude Opus 4.5**.

## Product goal (MVP)
Ship a working **Meta‑first** app for SMBs + small agencies that generates:
- diversified **creative packs** (images + copy) using an **Andromeda‑parametric** engine
- **reference edits** (Mode B) that preserve text/logo/product and subject identity
- simple scoring + guardrails so users can pick winners quickly
- export bundles for handoff to media buying

This v4 spec reflects a strategic pivot:
- Mode A is no longer “template compositing as the main engine.”  
  It is **Pure GenAI scenes + multimodal anchoring** for the hero product.
- Brand safety is achieved via **reliable finishing** (logo/text overlays when needed) + **quality gates** (text auditor, product fidelity).
- Mode B is **semantic editing first**, with protective fallback only when drift is detected.
- We add an **agentic Creative Director** chat panel that controls generation parameters (not raw prompts).

---

## 0) Instructions to the Agent (non‑negotiable)
1) Treat the docs in `/docs` as source of truth.
2) Do NOT expose API keys in client code. Generate server‑side.
3) Do NOT ask Gemini to invent logos/wordmarks. Official logos are overlays.
4) Packs must be generated ONLY via the **Andromeda‑Parametric Engine** (no random pack generation).
5) Implement quality gates:
   - Text Auditor (in‑image headline spelling)
   - Product Fidelity (hero object warp/misspelling)
   - Drift detection for reference edits (protected regions + identity)
6) Provide a user-visible toggle:
   - **Creative Mode (AI headline)** vs **Strict Mode (Overlay)**.
7) If Pro model fails, retry once with Fast model (automatic fallback).
8) Keep MVP scope SMB‑simple. Avoid enterprise dashboards.

---

## 1) Read these files first (in this repo)
- `docs/PRD_MVP.md`
- `docs/ARCHITECTURE.md`
- `docs/GENAI_PROMPTING_SPEC.md`
- `docs/ANDROMEDA_PARAMETRIC_ENGINE.md`
- `docs/BRAND_KIT_SPEC.md`
- `docs/UIUX_SPEC.md`
- `docs/COMPLIANCE_GUARDRAILS.md`
- `docs/TEST_PLAN.md`

Also read the memo:
- `docs/_inputs/andromeda_v2.md`

---

## 2) MVP Features to implement

### A) Brand Library (unified asset bucket)
- One upload bucket (drag/drop many files).
- Auto-categorize assets (logo, hero_product, winning_ad, style_reference, font).
- Allow user to override category quickly.

### B) Generate Pack (Mode A)
- Inputs:
  - placement (1:1 / 4:5 / 9:16 / 16:9)
  - objective + offer
  - pack size (5 default, 8, 12)
  - Safe Mode toggle: Creative vs Strict
- Engine:
  - build PromptSpecs via Andromeda‑Parametric presets
  - Mode A image generation (Gemini Pro + fallback to Fast)
  - optional in-image headline (Creative Mode only)
  - logo/text overlays (Strict Mode always; Creative Mode if auditor fails)
- Outputs:
  - variant grid
  - per variant: badges, score, warnings
  - actions: regenerate, mark winner, download, fix text, fix product

### C) Reference Edit (Mode B)
- Upload reference creative image.
- Edit intent controls (background, people, style).
- Identity Preservation toggle (default ON).
- Semantic edit first.
- Drift handling:
  - retry once if protected regions drift
  - restore protected regions OR overlay text if needed

### D) Quality Gates (required)
- Text Auditor:
  - if in-image headline used, OCR back the text
  - mismatch → auto overlay text for that variant
- Product Fidelity:
  - if hero product used, run critic/compare against reference
  - failure → offer “Fix Product” (regen product only) → hybrid composite fallback per variant
- Diversity enforcement:
  - ensure unique (pattern,lens,lighting) triples
  - regen duplicates (max 2 retries)

### E) Agentic Creative Director (MVP scope)
- Right sidebar chat that can:
  - switch hook angle / preset
  - change vibe (premium/urgent/UGC)
  - change placement and regen scope
- It must not expose raw prompts or edit pixels directly.

### F) Export
- Download ZIP:
  - images
  - copy JSON
  - manifest.json with promptSpec + audit results + score

---

## 3) Repo structure to generate
Create a monorepo (simple, one repo):
- `/frontend` (React + Vite + TS)
- `/backend` (FastAPI async)

Backend should follow `docs/ARCHITECTURE.md`.

---

## 4) Env template (create these files)
- `/backend/.env.example`
- `/frontend/.env.example` (no secret keys)

Backend env vars:
- `GEMINI_API_KEY=...`  (one key is enough; reuse for image + text)
Optional split:
- `GEMINI_IMAGE_API_KEY=...`
- `GEMINI_TEXT_API_KEY=...`

---

## 5) Acceptance criteria (must pass)
- User can create/select a brand and upload assets.
- User can generate a 5‑pack with visible diversity (lens/lighting/pattern differ).
- Creative vs Strict toggle changes finishing behavior.
- In‑image headline misspelling triggers Text Auditor fallback to overlay.
- Hero product warp triggers fidelity warning and “Fix Product” flow.
- Reference edit preserves logo/text and identity; drift triggers retry/fallback.
- Export zip contains all assets and a manifest.
- Test plan in `docs/TEST_PLAN.md` passes.

---

## 6) Start with a small vertical slice
Build the minimal end‑to‑end slice first:
Brand upload → generate 1 pack (5 variants) → preview grid → download export.
Then add:
Text auditor, product fidelity, reference edit, agent.

Do not build video in MVP; leave stubs per `docs/VIDEO_ROADMAP.md`.
