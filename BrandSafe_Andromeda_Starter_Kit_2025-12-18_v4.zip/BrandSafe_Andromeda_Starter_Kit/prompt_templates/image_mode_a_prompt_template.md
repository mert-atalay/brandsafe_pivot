# Mode A — Image Prompt Template (v4)
Use this as the **user prompt** for image generation (New Creative).

> System rules (“laws of physics”) must be included in the system instruction.
> See `docs/ANDROMEDA_PARAMETRIC_ENGINE.md`.

---

## PromptSpec (filled by backend)
- platform_placement: {{platform_placement}} (aspect ratio {{aspect_ratio}})
- objective: {{objective}}
- persona_label: {{persona_label}}
- desire_label: {{desire_label}}
- awareness_stage: {{awareness_stage}}
- hook_angle: {{hook_angle}}
- scene_pattern: {{scene_pattern}}
- camera_lens: {{camera_lens}}
- camera_distance: {{camera_distance}}
- lighting_style: {{lighting_style}}
- composition_rule: {{composition_rule}}
- negative_space_instructions: {{negative_space_instructions}}
- safe_mode: {{safe_mode}} (creative|strict)
- in_image_headline_enabled: {{in_image_headline_enabled}}

Hero object:
- hero_object_present: {{hero_object_present}} (true|false)

---

## User prompt
You are generating a **single, full‑frame** Meta ad creative image for placement {{platform_placement}} ({{aspect_ratio}}).

### Creative intent
- Target persona (abstract): {{persona_label}}
- Core desire: {{desire_label}}
- Awareness stage: {{awareness_stage}}
- Hook angle: {{hook_angle}}
- Scene pattern: {{scene_pattern}}

### Visual physics (do not deviate)
- Camera optics: {{camera_lens}}
- Camera distance: {{camera_distance}}
- Lighting: {{lighting_style}}
- Composition: {{composition_rule}}
- Negative space: {{negative_space_instructions}}

### Hero object anchoring (if provided)
{{#if hero_object_present}}
The attached image(s) show the **HERO OBJECT**.
Render the hero object with the same:
- geometry and proportions
- label spelling and markings
- brand name on packaging

Integrate it physically into the scene (real shadows/reflections; match lighting).
Do not stylize or warp the hero object.
{{/if}}

### Brand text + logos
{{#if (eq safe_mode "strict")}}
STRICT MODE:
- Do NOT render any brand logos/wordmarks.
- Do NOT render marketing text in the scene.
- The result should look like a clean photo/scene with appropriate negative space.
{{/if}}

{{#if (and (eq safe_mode "creative") in_image_headline_enabled)}}
CREATIVE MODE (in‑image headline allowed):
Render this headline inside the scene on a **physical surface** (sign / phone screen / paper / sticky note).
Headline (exact text): "{{headline_text}}"
Rules:
- headline must be legible
- no floating overlay text
- keep it short and natural (≤ 6 words)
- do not add any logos/wordmarks
{{/if}}

### Output rules
- Produce **one single full‑frame** image (no grids, collages, split screens).
- No watermarks.
- No invented logos.

Generate exactly 1 image.
