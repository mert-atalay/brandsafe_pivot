# Mode B — Reference Edit Prompt Template (v4)
Use this as the **user prompt** for image editing (Reference Edit).

Assumptions:
- The reference creative image is attached as inlineData.
- Optionally, a **Protection Overlay Map** image is also attached (same image with highlighted protected zones).

---

You are editing the provided image to create a **brand‑safe variation**.

## What MUST stay the same
- Preserve ALL existing logos/wordmarks and existing marketing text.
- Preserve the product/packaging identity and the overall layout.
- Do not redesign the ad.

## Identity preservation (default ON)
- Do NOT alter the subject’s facial features, skin tone, body type, or identity.
- Do NOT “beautify” or change ethnicity/age.
- If you must adjust lighting, relight realistically without changing identity.

## What is allowed to change
- Background: {{change_background_to}}
- People: {{change_people_to}}
- Props/setting details: {{props_changes}}
- Style: {{visual_style}}

## Protected regions
Treat highlighted / described regions as protected:
{{protected_regions_description}}

If protected regions are present:
- do not move them
- do not rewrite text
- do not change logos

## Output rules
- Maintain aspect ratio {{aspect_ratio}} exactly.
- Produce **one single full‑frame** image (no collage/grids).
- Do not add new logos or new text.

Return 1 edited image.
