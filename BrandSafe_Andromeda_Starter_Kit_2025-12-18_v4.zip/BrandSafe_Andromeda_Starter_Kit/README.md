# BrandSafe Andromeda Studio — Starter Kit (v4, 2025‑12‑18)

This folder is a **product + engineering spec pack** you can drop into a builder agent (Google Antigravity / Cursor / Claude Code) to build the BrandSafe app from scratch.

## What we’re building (the pivot)
We are pivoting from “template compositing (AdCreative-style)” toward an **Agentic Generative Studio** (Pencil-like outcomes) for SMBs and small agencies.

Why:
- Meta’s Andromeda era rewards **real creative diversity** (not near-duplicate variants).
- Gemini 3 Pro Image (“Nano Banana Pro”) can generate high‑fidelity scenes when conditioned on real product/brand references.
- SMBs want speed + confidence: generate packs, pick winners, export.

## Core outputs (MVP)
A “creative pack” contains:
- Images in Meta-ready placements (1:1, 4:5, 9:16, 16:9)
- Copy variants (primary text + headline + CTA)
- Diversity badges (pattern + lens + lighting)
- Score (0–100) + warnings
- Export bundle (ZIP + manifest)

## Two generation modes
- **Mode A (New Creative): Visual Conditioning**
  - Pure GenAI scenes with **multimodal anchoring** for hero products.
  - User-visible toggle:
    - Creative Mode (AI in-image headline) vs Strict Mode (overlay text)
  - Quality gates: Text Auditor + Product Fidelity + Diversity checks
- **Mode B (Reference Edit): Semantic Editing**
  - Preserve existing text/logo/product + preserve subject identity.
  - Drift detection + retry/fallback if protected regions change.

## What’s inside
- `MASTER_PROMPT_ANTIGRAVITY_OPUS45.md` — the single build prompt
- `docs/` — PRD, architecture, prompting spec, guardrails, test plan
- `prompt_templates/` — prompt templates for Mode A/B
- `templates/` — placement templates + safe zones
- `assets/` — placeholder images for dev testing
- `.env.example` — env template

## Recommended build path
1) Brand Library → Generate Pack → Export (end-to-end)
2) Add quality gates (Text Auditor, Product Fidelity) + “Fix” actions
3) Add Reference Edit + drift handling
4) Add Agentic Creative Director sidebar
5) Phase 2: Video with Veo (plan included)
