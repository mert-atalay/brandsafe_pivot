# Test Plan (MVP, v4) — 2025‑12‑18

## Unit tests (backend)
- Template loader validates safe zones are in bounds.
- Brand Composer overlays:
  - logo placement stays inside zone
  - text respects safe zones + wraps/clamps
- Parametric engine:
  - pack generator outputs unique (pattern,lens,lighting) triples
  - diversity score flags duplicates
- Quality gates:
  - **Text Auditor** returns extracted text + match flag
  - **Product Fidelity** returns pass/fail + reason codes
  - Drift detector flags protected-region changes
- Copy validator enforces strict JSON schema.

## Integration tests
- POST `/generate/pack` returns expected variant count (5/8/12).
- Pro model failure triggers fallback once (Pro→Fast).
- Returned image dimensions match requested aspect ratio.
- Strict Mode produces overlayed logo/text (no invented logos).
- Creative Mode with in-image headline:
  - if misspelled → auto switch to overlay for that variant
- Product fidelity failure flow:
  - warning emitted
  - “Fix Product” retry supported
  - repeated failure triggers Hybrid Mode for that variant
- Mode B reference edit:
  - JPG + PNG inputs work
  - identity preservation ON reduces drift
  - protected-region drift triggers retry/fallback

## Manual checks (UX)
- Results grid scrolls; generated assets visible without layout bugs.
- Variant cards show lens/lighting/pattern badges clearly.
- “Fix Text” and “Fix Product” actions are discoverable and work.
- Agent chat changes only parameters (no raw prompt exposure).
