# Implementation Plan (v4)

Ordered to ship a usable Meta‑first MVP fast.

## Phase 0 — Repo + dev sanity (Day 0)
- Monorepo scaffold:
  - `frontend/` (Vite React TS)
  - `backend/` (FastAPI async)
- One command to run both
- Local file storage for MVP
- Smoke tests: `/health` + basic UI render

## Phase 1 — Brand Library (context backbone)
- Brand CRUD
- **Unified asset bucket** upload (multi-file)
- Auto-categorization + quick manual override UI
- Brand rules: voice adjectives + do/don’t + claim constraints (optional)

## Phase 2 — Parametric Pack Engine (the backbone)
- Implement presets (pattern/lens/lighting/distance/composition)
- Pack generator enforces unique triples + diversity score
- No random pack generation path

## Phase 3 — Mode A Image Generation (Visual Conditioning)
- Gemini Pro call + Pro→Fast fallback
- Hero object anchoring (optional)
- Safe Mode toggle support:
  - Strict Mode: no in-image text
  - Creative Mode: optional in-image headline
- Return images + promptSpec per variant

## Phase 4 — Brand Composer (Strict finishing)
- Template safe zones loader
- Overlay logo + text into safe zones
- Export-ready images

## Phase 5 — Quality Gates + “Fix” actions
- Text Auditor (Creative Mode only)
  - mismatch → auto switch to overlay for that variant
- Product Fidelity (hero object only)
  - failure → warn + “Fix Product” retry
  - repeated failure → Hybrid composite per variant
- Add endpoints:
  - regenerate variant
  - fix text
  - fix product

## Phase 6 — Copy Generation
- Generate copy JSON per variant (primary/headline/CTA)
- Keep copy separate from persona/PDA internals (user doesn’t see prompts)

## Phase 7 — Mode B Reference Edit (Semantic)
- Reference edit with identity preservation ON by default
- Optional protection overlay map support
- Drift detection → retry once → fallback restore/overlay

## Phase 8 — Scoring + Compliance
- Score per `docs/AD_SCORING_SPEC.md`
- Warnings per `docs/COMPLIANCE_GUARDRAILS.md`
- Show “why” bullets + warning badges in UI

## Phase 9 — Agentic Creative Director (light MVP)
- Right sidebar chat
- Agent updates only parameters (hook/preset/placement/regenerate scope)

## Phase 10 — Export
- ZIP export: images + copy JSON + manifest with promptSpec + audit results

## Phase 2 (future) — Video
- Integrate Veo per `docs/VIDEO_ROADMAP.md` with async job pipeline
