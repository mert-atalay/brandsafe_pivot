### **Strategy Memorandum: The "Andromeda-Parametric" Prompt Engine**

To: Strategy Builder / GPT-5.2 Pro

From: Head of Product

Subject: Upgrading Prompt Logic for Meta Andromeda Compliance

#### **1\. The Core Problem: Why the old prompts failed**

The previous prompts were "narrative" (e.g., *"Act as a photographer and take a photo of..."*).

* **The Flaw:** Modern models (Gemini 3\) normalize "average" requests. If you ask 5 times for "a professional photo," it gives you 5 very similar-looking photos.  
* **The Business Risk:** Meta's **Andromeda Retrieval System** uses computer vision to group similar images. If our 5 variations share the same lighting/angle, Meta treats them as **1 Ad**, killing our reach.  
* **The Fix:** We must mathematically force **Pixel Diversity** by rotating hard parameters (Camera, Lighting, Distance) for every single generation.

#### **2\. The Solution: The P.D.A. Matrix Implementation**

We are adopting the **P.D.A. (Persona, Desire, Awareness)** framework found in the research.

The Logic:

We don't ask the AI to "be creative." We feed it a rigid tuple of variables that forces a distinct visual outcome.

| Variable | Andromeda Function | Example Value |
| :---- | :---- | :---- |
| **P (Persona)** | Defines the *Subject* | "Overwhelmed Dad" vs. "Tech-Savvy Teen" |
| **D (Desire)** | Defines the *Vibe/Lighting* | "Peace (Soft Light)" vs. "Speed (Motion Blur)" |
| **A (Awareness)** | Defines the *Layout/Text* | "Problem Aware (Focus on Pain)" vs. "Product Aware (Focus on Deal)" |

---

### **3\. The New "Master Prompt"** 

**Context for Strategy Builder:**

* **Why strictness?** To prevent the "Collage Bug" and ensure text legibility.  
* **Why distinct variables?** To evade Meta's "Creative Similarity" penalty.  
* **Why 'Container' logic?** Gemini renders text better when it's on a physical object (a sign, a screen) rather than floating in air.

#### **System Instruction (The Laws of Physics)**

*Inject this into the model configuration.*

Markdown  
You are the BrandSafe "Andromeda" Synthesis Engine (powered by Gemini 3 Pro).  
Your goal is to generate HIGH-FIDELITY, SEMANTICALLY DISTINCT ad creatives.

\*\*\* IMMUTABLE LAWS \*\*\*  
1\.  \*\*OUTPUT PHYSICS:\*\* Generate exactly ONE single full-frame image. NO grids, NO collages, NO split-screens.  
2\.  \*\*TEXT PHYSICS:\*\* Text must be "burned in" to the scene naturally. It must appear on a physical surface (sign, wall, screen, paper), not floating as a digital overlay unless specified as "Neon".  
3\.  \*\*DIVERSITY ENFORCEMENT:\*\* You must adhere strictly to the CAMERA, LIGHTING, and SCENE parameters provided. Do not revert to "standard studio lighting" if a specific mood is requested.  
4\.  \*\*BRAND SAFETY:\*\* Maintain product geometry perfectly. No distorted logos.

#### **The Parametric User Prompt (The Generator)**

*This f-string constructs the prompt based on the user's selected "Hook."*

Python  
\# The backend populates these variables based on the Hook Angle selected  
\# Example Hook: "Social Proof" \-\> Pattern: "UGC\_Selfie"

user\_prompt \= f"""  
\*\*\* STRATEGIC BLUEPRINT (P.D.A. Framework) \*\*\*  
\- \*\*TARGET PERSONA:\*\* {persona} (e.g. "Busy Corporate Executive")  
\- \*\*CORE DESIRE:\*\* {desire} (e.g. "To save time and feel in control")  
\- \*\*HOOK ANGLE:\*\* {hook\_angle} (e.g. "Social Proof / Testimonial")

\*\*\* VISUAL PHYSICS (Andromeda Diversity Signals) \*\*\*  
\- \*\*SCENE PATTERN:\*\* {scene\_pattern} (e.g. "UGC Selfie", "Macro Texture", "Wide Environmental")  
\- \*\*CAMERA OPTICS:\*\* {camera\_lens} (e.g. "24mm Wide Angle", "85mm Portrait Lens", "Fisheye")  
\- \*\*LIGHTING:\*\* {lighting\_style} (e.g. "Golden Hour Sun", "Hard Flash / Paparazzi", "Cool Neon")  
\- \*\*COMPOSITION:\*\* {negative\_space\_rule} (e.g. "Leave top-center 30% empty sky for UI overlay")

\*\*\* IMAGE GENERATION INSTRUCTION \*\*\*  
Generate a photo-realistic image capturing the {persona} experiencing {desire}.  
{ "Seamlessly composite the product bottle onto the surface." if mode \== "product" else "Focus on the human emotion and authenticity." }  
Use the {lighting\_style} to create a specific mood distinct from generic stock photos.

\*\*\* TEXT RENDERING TASK \*\*\*  
Render the headline: "{headline}"  
PLACEMENT STRATEGY: {text\_container} (e.g. "Written on a post-it note", "Displayed on a phone screen", "Embroidered on a jacket")  
"""

---

### **4\. The "Diversity Dictionary" (The Logic Layer)**

**Why this is needed:** The user might just click "Generate." We need a backend brain that translates "Generate" into 5 *different* prompts.

*Give this logic table to the Strategy Builder to implement in creative\_synth.py:*

**If User selects "Auto-Generate Pack", iterate through these 5 presets:**

1. **The "Authentic" (Social Proof)**  
   * Pattern: UGC Selfie  
   * Camera: iPhone Front Camera (24mm)  
   * Lighting: Natural Window Light (High Key)  
   * Text: On a social media comment bubble or sticky note.  
2. **The "Authority" (Founder/Trust)**  
   * Pattern: Studio Portrait  
   * Camera: 85mm Lens (Eye Level)  
   * Lighting: 3-Point Studio Light (Crisp)  
   * Text: On a clean wall behind the subject.  
3. **The "Visceral" (Texture/Quality)**  
   * Pattern: Macro Close-Up  
   * Camera: 100mm Macro Lens  
   * Lighting: Hard Rim Light (Moody)  
   * Text: Embossed on the product surface or label.  
4. **The "Urgent" (FOMO)**  
   * Pattern: Dutch Tilt / Action  
   * Camera: Wide Angle (Low POV)  
   * Lighting: Flash / High Contrast  
   * Text: Bright Neon or Red "Sale" tag.  
5. **The "Lifestyle" (Benefit)**  
   * Pattern: Environmental Wide  
   * Camera: 35mm Lifestyle  
   * Lighting: Warm Golden Hour  
   * Text: Integrated into the sky or negative space.

Why this works for Andromeda:

Each of these 5 presets produces a completely different histogram and visual embedding. Meta's AI will see them as 5 Unique Entities, maximizing your chance of finding a winner.

