# Andromeda‑Parametric Prompt Engine (v4)

This doc defines how BrandSafe forces **meaningful creative diversity** (Meta-first).
It upgrades the system from narrative prompting (“act like a photographer…”) to **parametric prompting**: hard parameters that produce distinct embeddings.

This approach is consistent with the memo in `docs/_inputs/andromeda_v2.md`.

---

## 1) The core problem
Narrative prompting causes modern image models to normalize outputs (5 “professional photos” become near-duplicates).  
Meta similarity grouping then treats these as effectively “one ad,” limiting delivery.

**Fix:** force diversity by rotating:
- camera optics (lens)
- camera distance
- lighting physics
- composition / negative space
- scene pattern

---

## 2) P.D.A. matrix (Persona, Desire, Awareness)
We adopt P.D.A because it binds **subject + vibe + layout needs** into one coherent brief.

- Persona → subject + context realism
- Desire → mood + lighting + motion
- Awareness → copy structure + composition needs

---

## 3) “Laws of Physics” (system rules)
Inject these into the image system instruction:

1) Output one single full-frame image (no grids/collages/splits).  
2) Obey camera + lighting + scene constraints exactly.  
3) Never invent logos/wordmarks.  
4) If text is requested in-image: render it on a physical surface (sign/screen/paper), not floating overlay.  
5) Maintain hero object geometry if a product reference is attached.

---

## 4) PromptSpec (backend-controlled)
The backend assembles a PromptSpec per variant with:
- hook_angle, awareness_stage
- persona_label, desire_label
- scene_pattern
- camera_lens, camera_distance, lighting_style
- composition + negative_space_instructions
- safe_mode: creative|strict
- hero_object_refs[] (optional)
- in_image_headline_enabled (optional)

---

## 5) Pack presets (the “diversity dictionary”)
The pack generator iterates a fixed set of presets so users don’t have to be creative.

Recommended 5-pack anchors:
1) Authentic (UGC selfie, natural light, phone cam)
2) Authority (studio portrait, crisp 3-point)
3) Visceral (macro texture, rim light)
4) Urgent (dutch tilt/action, flash/high contrast)
5) Lifestyle (environment wide, golden hour)

---

## 6) Enforcement algorithm (non-negotiable)
**All pack generation must go through this engine.**
No “random generation” path for packs.

Guarantee:
- each variant has a unique `(scene_pattern, camera_lens, lighting_style)` triple
- each variant differs in at least 2 of: lens, lighting, distance, composition

Then validate:
- copy similarity threshold (semantic / n-gram)
- promptSpec overlap (preset IDs)

If diversity score < threshold:
- regenerate only conflicting variants (max 2 retries per variant)

---

## 7) Brand text & logo strategy (Strict vs Creative)

### Strict Mode (recommended default)
- Gemini generates scene (and optionally hero object) without logos/wordmarks and without marketing text.
- Brand Composer overlays official logo + copy using templates/safe zones.

### Creative Mode (optional)
- Gemini may render a short headline in-image on a physical surface.
- **Text Auditor required:** if spelling mismatch → auto switch that variant to overlay.

---

## 8) Failure handling (must exist)
- **Product fidelity fail** → “Fix Product” (retry) → Hybrid composite (per-variant fallback).
- **In-image text misspelling** → auto overlay fallback (per-variant).
