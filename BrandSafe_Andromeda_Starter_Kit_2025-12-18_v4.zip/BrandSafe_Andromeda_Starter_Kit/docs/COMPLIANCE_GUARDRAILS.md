# Compliance & Brand-Safety Guardrails (v4, 2025‑12‑18)

BrandSafe is “rules first.”
This doc defines guardrails for:
- prompt generation
- copy generation
- image generation/editing
- quality gates + fallbacks

---

## Always-on guardrails
1) Do not generate disallowed content.
2) Do not generate deceptive claims (guarantees, “cures”, etc.).
3) Do not impersonate real people or brands.
4) Don’t generate sensitive personal data.

---

## Brand safety (non‑negotiable)
- Never ask Gemini to invent logos/wordmarks.
- Official logos are always preferred as overlays (Strict Mode default).
- If Creative Mode is used, it may render an in-image headline, but:
  - text is audited
  - failures switch to overlay automatically

---

## Platform safety (Meta-first)
MVP warnings:
- Collage/grid output (must be one full-frame image)
- Unreadable text (too small / low contrast)
- Text invading safe zones (for placements)
- High similarity between variants (Andromeda risk)

We do NOT attempt to bypass platform review systems.

---

## Quality gates (required)

### 1) Text Auditor (in-image text)
When a variant uses in-image headline:
- OCR/read back the rendered text
- Compare against expected headline
If mismatch:
- warn user
- automatically fallback to overlay text for that variant (Strict Mode)

### 2) Product Fidelity (hero object anchoring)
When a hero product is used:
- check for shape/label distortion
- check for obvious misspelling on packaging
If fail:
- warn user + show “Fix Product”
- allow regenerate product only with stricter conditioning
- if repeated failure → Hybrid Mode composite for that variant

### 3) Reference Edit Drift
For Mode B:
- detect drift in protected regions (logo/text areas)
- detect identity drift flags (face/skin tone/body changes)
If drift:
- retry once with stronger constraints
- if still drift → restore protected regions or overlay text

---

## Claims guardrails (copy)
Warn (don’t block MVP) on:
- medical claims
- guaranteed outcomes
- financial promises
- “best in the world” absolute claims (unless proven)
