# Security & Privacy Notes

## MVP stance
- Keep Gemini keys server-side.
- Store user uploads locally for dev; treat as sensitive.

## Later
- Supabase auth
- Signed URLs for asset access
- Per-team quota limits
- Audit logs for generated creatives
