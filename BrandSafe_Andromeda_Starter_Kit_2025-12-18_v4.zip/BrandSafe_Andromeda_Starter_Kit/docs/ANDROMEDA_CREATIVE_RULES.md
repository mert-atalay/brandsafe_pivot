# Andromeda‑era Creative Rules (v3, enforced)

> “Andromeda” is used here as shorthand for the current Meta delivery environment where
> retrieval + ranking + automation work best when you give the system a **portfolio** of meaningfully different creatives.

This v3 spec is paired with `docs/ANDROMEDA_PARAMETRIC_ENGINE.md` and is enforced by code (not “best effort”).

---

## Core idea
A pack should NOT be “the same ad 8 times.”

Small edits (tiny copy tweaks, slight background changes) often behave like near‑duplicates.  
We must **force pixel diversity** by rotating hard variables that change the visual embedding:
- camera lens (24mm vs 85mm vs macro)
- camera distance (wide vs mid vs close)
- lighting physics (golden hour vs hard flash vs low‑key studio)
- composition (POV vs centered vs dutch tilt)
- scene pattern (UGC vs studio vs infographic, etc.)

---

## Pack size targets
- MVP default: **8–12**
- Phase 2 target: **12–15** (+ video)

---

## What counts as a “different creative”
A variant must change at least **2** of these primary levers:
1) **Hook angle** (message)
2) **Scene pattern** (visual story format)
3) **Camera optics** (lens + distance + POV)
4) **Lighting** (type + mood)
5) **Setting / story** (environment + people)
6) **Format** (static vs motion; or at least different placement/layout)

If you only change *one* lever, you are probably creating duplicates.

---

## Hook angles (starter set)
Keep the list small and understandable for SMBs:
1. Attention / pattern break
2. Local relevance (optional)
3. Social proof / trust
4. Problem → solution
5. Benefits / outcomes
6. Authority / credibility
7. Offer / urgency (soft)
8. Education / “how it works”

Vertical‑specific angles should live in **BrandKit presets**, not hard‑coded globally.

---

## Scene patterns library (MVP)
Each variant also picks a **scene pattern** (see `docs/CREATIVE_PATTERNS_LIBRARY.md`).

---

## The P.D.A. layer (required)
Every variant is built from:
- **Persona** (subject realism)
- **Desire** (mood / emotion)
- **Awareness** (message structure / layout needs)

See `docs/ANDROMEDA_PARAMETRIC_ENGINE.md`.

---

## Visual diversification checklist (hard)
Each pack must cover:
- Settings: home / outdoors / workplace / store / studio
- People: none / single / duo / group; candid vs posed
- Camera: wide / mid / close, plus lens variety
- Lighting: daylight / warm indoor / golden hour / hard flash / low‑key
- Composition: negative space vs text‑container; rule‑of‑thirds vs centered
- Texture: UGC phone photo vs polished studio

---

## Copy diversification checklist (hard)
- First 5 words differ across variants
- Different promise framing (save time, feel confident, look professional, etc.)
- Different objections handled (trust, price, time, uncertainty)
- Different CTA framing (Get quote / Book / Learn more / Shop)

---

## Diversity scoring (MVP)
Compute a score **0–1** from:
- hook angle uniqueness (required)
- scene pattern uniqueness (required)
- **parametric uniqueness**: lens + lighting + distance triple (required)
- copy similarity (semantic OR n‑gram)
- visual descriptor overlap (keywords + preset ids)

**Enforcement**
Regenerate conflicting variants until:
- score ≥ threshold (default **0.70**) OR
- attempts == 2 per variant

Always surface:
- diversity score (0–1)
- “what changed” (lens/lighting/pattern badges)
in the UI so users understand why packs matter.
