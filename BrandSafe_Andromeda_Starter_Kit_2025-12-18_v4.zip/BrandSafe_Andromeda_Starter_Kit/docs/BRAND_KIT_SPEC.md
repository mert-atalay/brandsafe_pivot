# Brand Kit Spec (v4, 2025‑12‑18)

The Brand Kit is the center of “context learning.”
We are not fine‑tuning in MVP; we are conditioning on saved brand assets (“temporary LoRA / in‑context RAG”).

## MVP UX principle
**One upload bucket**, not 5 different uploaders.
Users drag/drop everything; the system categorizes, then the user can override quickly.

---

## Data model (minimal)

### BrandKit
- `brand_id`
- `brand_name`
- `website_url` (optional)
- `brand_voice`: `{ adjectives[], do_list[], dont_list[] }`
- `claim_constraints[]` (optional MVP)

### BrandAsset (unified bucket)
Each uploaded file becomes a BrandAsset:
- `asset_id`
- `brand_id`
- `file_url`
- `mime_type`
- `asset_type` (auto + user override):
  - `logo`
  - `hero_product`
  - `winning_ad`
  - `style_reference`
  - `font`
  - `other`
- `tags[]` (optional: “luxury”, “UGC”, “holiday”)
- `notes` (optional)

### Derived convenience sets (computed)
- `logos[]`
- `hero_products[]`
- `winning_ads[]`
- `references[]`

---

## Auto‑categorization (Agent‑assisted)
When new assets are uploaded:
1) Run a lightweight classifier:
   - If filename hints (logo, brand, font) → categorize
   - Else use Gemini vision/text:
     - “Is this a logo? product shot? ad creative? font?”
2) Present results as editable chips:
   - Logo / Product / Winning Ad / Style Ref / Font / Other

**MVP requirement:** user can fix wrong categorization in <10 seconds.

---

## Context learning (“Brand Brain”) — In‑Context RAG
At generation time:
1) Retrieve:
   - 1–2 logos (official)
   - 1–3 hero product images (if provided)
   - 3–6 winning ads / style references (top‑K)
2) Inject:
   - brand voice rules (text)
   - multimodal references (images)
3) Use these assets as anchors for prompts.

Later (Phase 1.5+):
- store embeddings for winning ads and retrieve the most relevant assets per promptSpec.

---

## Brand-safe rules (non‑negotiable)
- Do NOT ask Gemini to invent logos/wordmarks.
- Default is **Strict Mode** for text + logo:
  - logo + copy are rendered by the Brand Composer using templates.
- Optional **Creative Mode**:
  - Gemini may render a short in‑image headline on a physical surface,
  - but text is audited; if incorrect, switch to overlay automatically.
