# Template + Safe Zones (v3)

## What is a template?
A template defines:
- output resolution
- safe zones (areas that should remain uncluttered for platform UI)
- overlay zones (logo/headline/CTA)

## MVP templates (Meta)
- 1080x1080 (1:1)
- 1080x1350 (4:5)
- 1080x1920 (9:16)
- 1920x1080 (16:9)

## Safe zones (defaults)
Conservative defaults (editable later):
- Story/Reels 9:16: avoid top 250px and bottom 350px for UI overlays
- Feed 1:1 and 4:5: keep ~80px padding around edges for text/logo
- 16:9: keep ~120px padding on left/right edges

## Zone types
- IMAGE_BG (full canvas)
- LOGO
- HEADLINE
- SUBHEAD
- CTA

Store templates as JSON under `/templates/*.json`.

---

## Template‑to‑Prompt translator (critical)
Templates are not only for compositing. They are also used to guide **pure generation**.

The backend must translate template safe zones into a natural language instruction for Mode A:

Example:
- template safe zones: “top 20% reserved; bottom 15% reserved”
- generated instruction:
  - “Leave the top 20% as clean sky/solid wall (empty negative space).”
  - “Keep the bottom 15% uncluttered (simple background, no faces).”

This prevents:
- UI overlays covering faces
- text overlay collisions
- and makes packs export-ready with minimal manual work.
