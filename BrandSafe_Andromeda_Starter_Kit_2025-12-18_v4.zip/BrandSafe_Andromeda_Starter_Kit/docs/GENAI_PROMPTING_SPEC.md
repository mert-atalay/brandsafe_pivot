# GenAI Prompting Spec (Gemini / Nano Banana Pro) — v4 (2025‑12‑18)

This document defines **how we prompt** and **how we configure** Gemini calls so outputs are:
- on‑brief
- brand‑safe
- diversified (Andromeda‑parametric)
- reliable under failure cases (text misspelling, product warp, edit drift)

---

## Models (Dec 2025 baseline)
- **Text / Copy / Agent**: `gemini-3-pro-preview` (or cheaper flash model for agent)
- **Image Pro (Nano Banana Pro)**: `gemini-3-pro-image-preview` (default)
- **Image Fast**: `gemini-2.5-flash-image` (fallback + optional user toggle)

> The system must support Pro → Fast automatic fallback (retry once).

---

## Prompt contract (the intermediate layer)
We never generate by “raw prompt strings.” We generate by assembling a **PromptSpec**:

Minimum PromptSpec fields:
- objective, placement, aspect_ratio
- hook_angle, awareness_stage
- persona_label, desire_label (abstract labels)
- scene_pattern
- camera_lens, camera_distance, lighting_style
- composition + negative_space_instructions (template→prompt translator)
- safe_mode: `creative` | `strict`
- hero_object_refs[] (optional images)
- in_image_headline_enabled (bool)
- headline_text (optional)

---

## System instruction (“laws of physics”)
Use the Andromeda‑Parametric rules:
- 1 full‑frame image only (no grids/collages)
- obey camera + lighting + pattern exactly
- never invent logos
- if text is requested in-image: place it on a physical surface, not floating

Reference: `docs/ANDROMEDA_PARAMETRIC_ENGINE.md` and `docs/_inputs/andromeda_v2.md`.

---

## Mode A — New Creative (Visual Conditioning / Multimodal Anchoring)

### What we send to Gemini
**Content parts** (user message):
1) brief text (PromptSpec rendered into natural language)
2) optional hero product images (inlineData or URLs) labeled as **Hero Object**
3) optional 3–6 brand reference images (winning ads / style refs)

### Hero Object instruction (critical)
If hero_object_refs exist, include:

- “The attached image(s) show the HERO OBJECT. Render it with the same geometry, markings, proportions, and label spelling.”
- “Integrate it physically into the scene (matching shadows, reflections, and lighting).”
- “Do not change the brand name on the product.”

### Safe modes (Creative vs Strict)
- **Strict mode** (default recommended for SMB reliability):
  - “Do not render any logos or marketing text in the scene.”
  - We will overlay official logo + copy with Brand Composer.
- **Creative mode** (optional, prettier, riskier):
  - Allows a short **in‑image headline** on a physical surface (sign / sticky note / phone screen).
  - Must keep headline short (≤ 6 words).
  - **Requires Text Auditor** after generation.

### Quality gates after Mode A generation
After the image is produced:
1) **Product Fidelity Check** (if hero object used)
   - If fail: warn + offer “Regenerate product only” and/or “Switch to Hybrid (product composite)”
2) **Text Auditor** (if in_image_headline_enabled)
   - OCR the rendered text
   - If mismatch: automatically switch that variant to overlay text

---

## Mode B — Reference Edit (Semantic editing first)

### What we send to Gemini
Content parts (user message):
1) edit instruction text
2) reference ad image (inlineData)
3) optional “Protection Overlay Map” image (same image with rectangles over protected regions)

### Core instructions
- “Preserve ALL existing logos/wordmarks and existing marketing text.”
- “Preserve product identity and packaging.”
- “Preserve layout (do not redesign the ad).”
- “Only change: background / people / props as requested.”
- **Identity Preservation (default ON):**
  - “Do not alter the subject’s face, facial features, skin tone, body type, or identity.”

### Drift handling
After editing:
- Run drift detector:
  - protected text/logo regions changed?
  - subject identity drift flags?
- If drift:
  - retry once with stronger constraints
  - final fallback: restore protected regions OR move to overlay text

---

## Retry & fallback rules (non‑negotiable)
- If Pro request fails: retry once with Fast.
- If text auditor fails: do NOT keep bad text; switch to overlay for that variant.
- If product fidelity fails twice: enable Hybrid Mode for that variant (composite the product).

---

## “Text Auditor” implementation guidance
Use a lightweight vision model call:
- Provide the generated image
- Ask for JSON:
  - extracted_text
  - spelling_confidence
  - match_to_expected (true/false)
If mismatch → trigger strict overlay fallback automatically.

---

## Prompt templates
See:
- `prompt_templates/image_mode_a_prompt_template.md`
- `prompt_templates/image_mode_b_prompt_template.md`
- `prompt_templates/copy_*`
