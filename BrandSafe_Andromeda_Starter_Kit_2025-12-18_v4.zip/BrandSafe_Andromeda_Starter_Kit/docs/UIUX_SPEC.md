# UI/UX Spec (v4) — Pencil‑like vibe, SMB‑simple (2025‑12‑18)

## Design goals
- Clean, spacious, card-based
- Feels like: “upload brand → generate diversified ad pack → export”
- Minimal jargon. No prompt engineering required.
- Preview-first: results appear immediately, not hidden behind tabs.
- Parametric diversity is visible via **badges** (lens/lighting/pattern), not settings walls.

## Navigation (MVP)
Left nav:
- Home
- Brand Library
- Generate Pack
- Reference Edit
- Video (Coming soon)

Top bar:
- Brand selector
- Export actions (when in a pack)

Right sidebar (MVP differentiator):
- **Creative Director Agent** chat
  - controls: hook angle / vibe / preset / placement / regenerate scope
  - does NOT pixel-edit in MVP

---

## Screen details

### 1) Home
- “Start” cards:
  - Create / Select Brand
  - Generate a Pack
  - Edit a Reference Ad
- Recently generated packs (list)

### 2) Brand Library (Brand Brain)
**Unified asset upload:**
- One big dropzone: “Drop logos, product photos, and winning ads”
- After upload, show auto-categorized chips:
  - Logo / Product / Winning Ad / Style Ref / Font / Other
- User can click to correct category fast.
- Brand Rules:
  - voice adjectives (3–6)
  - do/don’t list
  - claim constraints (optional)

### 3) Generate Pack (Mode A)
Left panel:
- Placement selector: Feed (1:1), Feed (4:5), Story/Reel (9:16), Landscape (16:9)
- Objective: Awareness / Leads / Sales
- Offer / CTA (simple)
- **Safe Mode toggle (visible):**
  - Creative Mode (AI headline) vs Strict Mode (Overlay text)
- Pack size: 5 (default), 8, 12
- Generate button

Center/right:
- Variant grid with thumbnails
- Variant Card shows:
  - hook angle + scene pattern
  - lens + lighting badges
  - score (0–100) + 3–6 “why” bullets
  - warnings badges (text drift, product drift, similarity)
  - actions:
    - Regenerate variant
    - Mark winner
    - Download
    - **Fix Text** (forces overlay for that variant)
    - **Fix Product** (regenerate product only / switch hybrid)

### 4) Reference Edit (Mode B)
Layout: left controls, right preview
Left controls:
- Upload reference ad
- Edit intent dropdowns:
  - Background (change to…)
  - People (change to…)
  - Style (UGC / premium / playful / etc.)
- **Identity Preservation** toggle (default ON)
- Generate edit button
- If drift warnings appear, show 1‑click actions:
  - Retry with stricter constraints
  - Restore protected regions
  - Force overlay text

### 5) Video (Coming soon)
- Disabled for MVP, but placeholder route exists.

---

## Agentic Co‑Pilot scope (MVP)
Allowed:
- update hook angle
- switch preset (UGC / premium / urgent)
- change placement + pack size
- regenerate selected variants

Not allowed (MVP):
- direct pixel painting
- writing raw prompts
- changing templates/safe zones beyond simple toggles
