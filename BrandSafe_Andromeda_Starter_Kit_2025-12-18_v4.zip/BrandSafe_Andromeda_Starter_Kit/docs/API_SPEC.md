# API Spec (MVP, v4) — 2025‑12‑18

Backend contract for the web app.
All Gemini calls happen server‑side.

## Conventions
- JSON request/response
- Images returned as asset ids (served via `/assets/{id}`)
- For MVP, store files on disk; later swap to Supabase Storage.

---

## Health
### GET /health
Returns `{ "ok": true }`.

---

## Brands

### POST /brands
Create a brand.
Input:
```json
{ "brand_name": "Acme", "website_url": "https://..." }
```

### GET /brands
List brands.

### GET /brands/{brand_id}
Get brand + derived categories.

### POST /brands/{brand_id}/assets
Upload one or more files (multipart).
Backend creates BrandAsset rows and runs auto‑categorization.

### PATCH /brands/{brand_id}/assets/{asset_id}
Update asset_type (user override) and tags.

---

## Generate Pack (Mode A)

### POST /generate/pack
Input:
```json
{
  "brand_id": "...",
  "campaign_brief": {
    "objective": "leads",
    "offer": "Book a tour",
    "placement": "meta_story",
    "pack_size": 5
  },
  "safe_mode": "strict",
  "in_image_headline_enabled": false
}
```

Output:
```json
{
  "pack_id": "...",
  "variants": [
    {
      "variant_id": "...",
      "prompt_spec": { },
      "image_asset_id": "...",
      "composited_asset_id": "...",
      "copy": { "primary_text": "...", "headline": "...", "cta": "..." },
      "score_0_100": 82,
      "warnings": ["TEXT_MISMATCH"]
    }
  ]
}
```

### POST /generate/variant/{variant_id}/regenerate
Regenerate a single variant (same PromptSpec unless patched).

### POST /generate/variant/{variant_id}/fix_text
Force overlay text finishing for this variant.

### POST /generate/variant/{variant_id}/fix_product
Retry with stricter hero object anchoring; may switch to Hybrid Mode per variant.

---

## Reference Edit (Mode B)

### POST /reference/edit
Multipart input:
- reference_image
- optional protection_overlay_map
- JSON intent fields (background/people/style)
Output:
- edited image asset id + warnings + audit results

---

## Export

### POST /export/pack/{pack_id}
Returns a ZIP containing:
- images
- copy JSON
- manifest.json (promptSpec + scores + audits)

---

## Agentic Creative Director

### POST /agent/chat
Input:
```json
{
  "brand_id": "...",
  "pack_id": "...",
  "message": "Make it more premium",
  "context": { "current_prompt_spec": { } }
}
```

Output:
```json
{
  "assistant_message": "...",
  "actions": [
    { "type": "update_params", "patch": { "lighting_style": "low_key_studio" } },
    { "type": "regenerate", "scope": "pack" }
  ]
}
```
