# Architecture (MVP, Meta‑first) — v4 (2025‑12‑18)

## Stack
- Frontend: React + Vite + TypeScript
- Backend: Python FastAPI (async)
- Storage: Local filesystem (MVP), Supabase Storage optional
- DB: Optional Supabase Postgres for brands + assets + packs + feedback + embeddings (Phase 1.5+)

## Guiding principles
- **Meta-first**: pack generation + diversification is the core.
- **Pure GenAI scenes** with **multimodal anchoring** for hero products.
- **Brand safety finishing**: logo + typography are reliable via Brand Composer (Strict Mode default for many SMBs).
- Quality gates catch failure cases: product warp, misspelled text, drift in reference edits.
- Agentic UX: user directs outcomes, not prompts.

---

## High‑level flow
Web app → FastAPI orchestrator →
- Gemini Text (copy JSON)
- Gemini Image (Mode A / Mode B, Pro w/ Flash fallback)
→ Quality Gates (text auditor + fidelity check + drift detector)
→ Brand Composer (overlay when needed)
→ Scoring + compliance
→ Storage + export

---

## Key domain objects
- **BrandKit**
  - brand_name, voice rules
  - brand_assets[] (unified bucket)
  - derived categories: logos[], hero_products[], references[], fonts[]
- **CampaignBrief**
  - objective, offer, placement(s), audience signals, PDA labels
- **PromptSpec** (per variant)
  - hook_angle, awareness_stage, persona_label, desire_label
  - scene_pattern
  - lens, distance, lighting, composition
  - negative_space_instructions (template→prompt translator)
  - safe_mode: creative|strict
  - hero_object_refs[] (optional)
  - in_image_headline_enabled (optional)
- **Variant**
  - promptSpec
  - generated_image_id
  - composited_image_id (optional)
  - copy_json
  - score + warnings + diversity_subscore
  - audit_results (text_audit, product_fidelity, drift)

---

## Backend module layout (recommended)
`app/`
- `api/`
  - `brands.py` (brand kit CRUD)
  - `generate_pack.py`
  - `reference_edit.py`
  - `export.py`
  - `agent_chat.py`
- `core/`
  - `config.py` (keys, env)
  - `logging.py`
  - `rate_limit.py` (optional)
- `generation/`
  - `copy.py` (Gemini text → strict JSON)
  - `image_mode_a.py` (Visual Conditioning)
  - `image_mode_b.py` (Semantic editing)
  - `pack.py` (orchestrates parametric presets)
- `parametric/`
  - `presets.py` (lens/lighting/distance presets)
  - `engine.py` (pack enumeration + diversity validation)
- `quality/`  ✅ new
  - `text_auditor.py` (OCR via lightweight vision model)
  - `product_fidelity.py` (hero object compare/critic)
  - `drift_detector.py` (protected region diffs / identity drift heuristics)
- `composer/`
  - `templates.py` (template JSON loader)
  - `render.py` (Pillow compositing: logo + text into safe zones)
- `scoring/`
  - `score.py` (heuristics + optional Gemini critic)
- `compliance/`
  - `rules.py` (claims, unsafe language, overflow warnings)
- `storage/`
  - `local.py`
  - `supabase.py` (optional)

---

## Modes & toggles (how reliability is achieved)

### Mode A — Visual Conditioning (New Creative)
1) Build PromptSpecs via **Parametric Engine** (no “random generation” in packs).
2) Generate image(s) with Nano Banana Pro (fallback Flash).
3) Run quality gates:
   - product_fidelity (if hero object used)
   - text_auditor (if in-image text enabled)
4) Decide finishing:
   - Strict Mode → Brand Composer overlays copy/logo
   - Creative Mode → keep in-image headline if auditor passes; still composite official logo
5) Score + warnings + export.

### Mode B — Semantic Reference Edit
1) Send reference image + edit intent (+ optional protection overlay map).
2) Include identity preservation instructions in prompt.
3) Run drift detector:
   - protected text/logo regions changed?
   - subject identity drift flags?
4) If drift detected:
   - retry with stronger constraints once
   - final fallback: restore protected regions or switch to Strict overlay text if OCR fails

---

## Why server‑side generation
- Do not expose API keys in the browser.
- Central retries + fallback logic (Pro→Flash, semantic→strict).
- Central logging, caching, and future job queues (video LRO operations).
