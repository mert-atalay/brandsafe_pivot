# Quality Gates & Failure Handling Protocol (v1)

Purpose: when we trust Pure GenAI, we need **explicit failure handling** so users aren’t stuck.

This protocol defines:
- what we check automatically
- what warnings we show
- what “Fix” actions exist

---

## 1) Text Auditor (in-image headline)
Applies only when:
- safe_mode = creative AND in_image_headline_enabled = true

Check:
- OCR the generated image
- Extract visible headline text
- Compare to expected headline

If FAIL:
- set warning: `TEXT_MISMATCH`
- automatically switch that variant to overlay text (Strict overlay finishing)
- keep the image (scene) if it is otherwise good

User actions:
- “Fix Text” (forces overlay)
- “Regenerate Variant” (new scene)

---

## 2) Product Fidelity (hero object anchoring)
Applies when:
- hero_object_refs are attached

Checks (MVP heuristic + optional critic):
- Is the hero object present?
- Is the overall shape/label obviously warped?
- Are there obvious spelling changes on packaging?

If FAIL:
- set warning: `PRODUCT_FIDELITY_LOW`
- show Fix Product actions

User actions:
- “Fix Product” (regen with stricter anchoring; keep the same param preset)
- “Hybrid Mode” (generate scene, then composite official product PNG for accuracy)

Note: Hybrid Mode is per-variant fallback, not default.

---

## 3) Reference Edit Drift (Mode B)
Applies always in Mode B.

Checks:
- protected text/logo rectangles changed (pixel diff threshold)
- identity drift flags (face/skin/body changes)

If FAIL:
- warning: `DRIFT_DETECTED`
- auto retry once with stronger constraints
- if still failing:
  - restore protected regions OR switch to overlay text

User actions:
- “Retry Strict”
- “Restore Protected Regions”
- “Force Overlay Text”

---

## 4) Diversity Gate (pack-level)
Applies for any pack generation.

Checks:
- unique (pattern,lens,lighting) triples across pack
- similarity threshold for prompts/copy

If FAIL:
- regenerate only the conflicting variants (max 2 retries)
