# PRD — MVP Requirements (v4, 2025‑12‑18)

## Why this product exists (pivot summary)
We are pivoting BrandSafe from a “template compositing dashboard” into an **Agentic Generative Studio** (Pencil‑style outcomes, SMB‑friendly scope).

**Why the pivot:**
- Meta’s Andromeda era rewards **genuinely distinct creative** (not 10 near‑duplicates).
- Google Gemini 3 Pro Image (“Nano Banana Pro”) is now strong enough to **render high‑fidelity scenes** when conditioned on real brand/product references.
- SMBs need speed + confidence: generate diversified packs, pick winners, export.

---

## Target users (MVP)
- SMB marketers (solo / small teams)
- Small agencies (5–50 clients)
- Not enterprise suites (Typeface‑level workflows are out of scope)

---

## Top priority outcomes
1) Generate a **Meta creative pack** (images + copy) that is:
   - immediately usable
   - **mathematically diversified** via parametric rotation (lens/lighting/distance)
   - brand‑safe by construction
2) Generate **reference edits** that preserve identity and brand elements:
   - semantic editing first (no “Frankenstein” pixel locks by default)
   - **automatic protection fallback** if text/logo/product drift
3) Give users confidence:
   - simple score (0–100) + warnings
   - quality gates for “product fidelity” + “text correctness”

---

## Core workflows (MVP)

### A) Brand setup (“Brand Brain”)
- Single **Brand Assets bucket** upload (drag/drop many files).
- Agent auto‑categorizes into:
  - logo(s)
  - product/hero object(s)
  - winning ads / references
  - optional fonts / style references
- User can override categories quickly.
- Store Brand Rules: voice adjectives + do/don’t + claim constraints.

### B) Generate Pack (Mode A — New Creative)
Input:
- brand selected
- campaign brief (offer, objective, placement, audience signals)
- toggle: **Creative Mode vs Strict Mode** (see below)
Output:
- a pack (default 5; optional 8–12) with:
  - images
  - copy set (primary text, headline, description, CTA)
  - per‑variant score + warnings
  - export bundle

### C) Reference Edit (Mode B)
Input:
- upload reference ad creative
- edit intent: background / people / vibe
- identity preservation (default ON)
Output:
- edited ad variant
- text/logo drift warnings + automatic fallback if needed

### D) Export
- Download ZIP with clear naming:
  - brand_campaign_date__variant_01__hook_pattern_lens_lighting.png
  - copy.json (per variant)

---

## Two modes + reliability toggles

### Mode A (New Creative): “Visual Conditioning” (default)
- If a **hero product** is provided: attach product image(s) to Gemini as **multimodal anchors**.
- Prompt instructs: “Render this hero object exactly; integrate physically (lighting/shadows).”
- Andromeda‑Parametric engine rotates hard parameters across the pack.

### Mode B (Reference Edit): “Semantic Editing” (default)
- Edit the reference image while preserving layout + identity.
- Strong identity‑preservation instructions (“do not change face/skin tone/body”).
- Optional protection overlay map (rectangles) as a second reference image.

### Creative Mode vs Strict Mode (user‑visible toggle)
- **Creative Mode (AI)**:
  - allows “in‑image headline” on physical surfaces (if selected)
  - highest realism / cohesion
  - risk: spelling drift / micro‑warps → caught by quality gates
- **Strict Mode (Overlay)**:
  - AI generates scene; **logo + copy are always rendered by Brand Composer**
  - safest for SMBs who fear hallucinations
  - slightly flatter look, but reliable typography

### Hybrid fallback (automatic + user override)
If **product fidelity** fails (hero object warps/label wrong):
- user can click **“Bad Product → Fix Product”**
- system retries with stricter conditioning
- if still failing, fall back to **Hybrid Mode** for that variant:
  - generate background/scene
  - composite official product PNG in the hero zone (lower realism but correct)

---

## Quality gates (MVP requirements)
1) **Product Fidelity Check**
   - compare generated hero object vs reference (vision critic + heuristics)
   - if fail → warn + offer “Regenerate product only” / “Switch to Hybrid”
2) **Text Auditor**
   - if in‑image text is used, read it back (vision OCR)
   - if misspelled → auto switch to overlay text (Strict Mode for that variant)
3) **Diversity Enforcement**
   - validate unique (pattern, lens, lighting) triples
   - if too similar → regen conflicting variants (max 2 retries)

---

## Agentic Co‑Pilot (MVP scope)
- Co‑Pilot controls **generation parameters only**:
  - hook angle, scene pattern, vibe, lens/lighting preset, placement
  - regenerate pack or selected variants
- Co‑Pilot does NOT “paint pixels” in MVP.

---

## Video (plan, not a blocker)
- MVP: do not block release for video
- Phase 2: add Veo‑based video (see `docs/VIDEO_ROADMAP.md`)
- MVP must keep pipeline modular so video variants can become another asset type later.

---

## Non‑goals
- Not a full creative editor like Canva.
- Not an enterprise creative intelligence suite.
- Not copying Pencil UI 1:1.

---

## Key UX requirement
“One decision per screen.”
If users need prompt engineering knowledge, we failed.
