# Claude Opus 4.5 — Strategy Review Prompt (Pivot Context)

## Context (what changed and why)
You are reviewing this spec pack **inside an existing BrandSafe project**.

We are making a deliberate pivot:
- FROM: “Template compositing / template assembler” (AdCreative-style)
- TO: “Agentic Generative Studio” (Pencil-like outcomes) with **Pure GenAI scenes** + **multimodal anchoring**.

Why:
- Meta’s Andromeda era rewards **real diversity** (not near-duplicates).
- Gemini 3 Pro Image (“Nano Banana Pro”) can produce cohesive, high-fidelity scenes when conditioned on real brand/product references.
- SMBs need speed + reliability: generate packs, pick winners, export.

What stays the same:
- brand safety is core
- Meta-first focus
- two modes: New Creative + Reference Edit
- no enterprise scope creep

---

## Your task
Read the entire folder and provide a rigorous critique.

### Files to read first
- README.md
- MASTER_PROMPT_ANTIGRAVITY_OPUS45.md
- docs/PRD_MVP.md
- docs/ARCHITECTURE.md
- docs/GENAI_PROMPTING_SPEC.md
- docs/ANDROMEDA_PARAMETRIC_ENGINE.md
- docs/QUALITY_GATES_PROTOCOL.md
- docs/BRAND_KIT_SPEC.md
- docs/UIUX_SPEC.md

Also read the strategy memo:
- docs/_inputs/andromeda_v2.md

---

## What I want from you (output format)
A) Executive Verdict (is this strong enough to build now?)
B) Top 10 gaps/risks (prioritized)
C) Prompting critique (Mode A, Mode B, copy, agent)
D) Diversification enforcement critique (does it guarantee distinctness?)
E) Reliability critique:
   - text auditor loop
   - product fidelity + hybrid fallback
   - reference edit drift / identity preservation
F) MVP scope sanity:
   - what to cut
   - what to add (only high-leverage)
G) Concrete edits:
   - list exact files + suggested changes

Be blunt. Optimize for a shippable, SMB-friendly v1.
